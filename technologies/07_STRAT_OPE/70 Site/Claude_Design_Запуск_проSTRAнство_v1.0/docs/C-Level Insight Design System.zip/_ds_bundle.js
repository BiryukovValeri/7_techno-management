/* @ds-bundle: {"format":4,"namespace":"CLevelInsightDesignSystem_27a32f","components":[{"name":"CTABlock","sourcePath":"components/conversion/CTABlock.jsx"},{"name":"RequestDiagnosticsForm","sourcePath":"components/conversion/RequestDiagnosticsForm.jsx"},{"name":"Band","sourcePath":"components/core/Band.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"},{"name":"CaseCard","sourcePath":"components/evidence/CaseCard.jsx"},{"name":"CaseFlow","sourcePath":"components/evidence/CaseFlow.jsx"},{"name":"MaterialCard","sourcePath":"components/evidence/MaterialCard.jsx"},{"name":"OnePageBlock","sourcePath":"components/evidence/OnePageBlock.jsx"},{"name":"Footer","sourcePath":"components/navigation/Footer.jsx"},{"name":"Header","sourcePath":"components/navigation/Header.jsx"},{"name":"StickySectionNav","sourcePath":"components/navigation/StickySectionNav.jsx"},{"name":"ComparisonMatrix","sourcePath":"components/positioning/ComparisonMatrix.jsx"},{"name":"WhatItIsNot","sourcePath":"components/positioning/WhatItIsNot.jsx"},{"name":"OpportunityBlock","sourcePath":"components/sections/OpportunityBlock.jsx"},{"name":"SituationBlock","sourcePath":"components/sections/SituationBlock.jsx"},{"name":"TechnologyHero","sourcePath":"components/sections/TechnologyHero.jsx"},{"name":"TechnologyIntro","sourcePath":"components/sections/TechnologyIntro.jsx"},{"name":"MobileVisualizationPreview","sourcePath":"components/technology/MobileVisualizationPreview.jsx"},{"name":"ProductLadder","sourcePath":"components/technology/ProductLadder.jsx"},{"name":"VisualizationShowcase","sourcePath":"components/technology/VisualizationShowcase.jsx"}],"sourceHashes":{"assets/image-slot.js":"fff26d081c8d","components/conversion/CTABlock.jsx":"60883e42c3f4","components/conversion/RequestDiagnosticsForm.jsx":"3218c35c5887","components/core/Band.jsx":"ff5d8a5cf2b0","components/core/Button.jsx":"67b215eec410","components/core/Tag.jsx":"a97d31bc5c61","components/evidence/CaseCard.jsx":"d106518a6a8d","components/evidence/CaseFlow.jsx":"10059fa21518","components/evidence/MaterialCard.jsx":"2c103c797436","components/evidence/OnePageBlock.jsx":"55013dcdb245","components/navigation/Footer.jsx":"cb97cef4302e","components/navigation/Header.jsx":"4b8d01dbfe72","components/navigation/StickySectionNav.jsx":"082d000b382b","components/positioning/ComparisonMatrix.jsx":"168b2d249ef9","components/positioning/WhatItIsNot.jsx":"48304d37771e","components/sections/OpportunityBlock.jsx":"b4021f886fef","components/sections/SituationBlock.jsx":"aec1edf24fbf","components/sections/TechnologyHero.jsx":"cf0439427c6c","components/sections/TechnologyIntro.jsx":"aa0ceed5ba7d","components/technology/MobileVisualizationPreview.jsx":"b937eed267ca","components/technology/ProductLadder.jsx":"fd388192ee29","components/technology/VisualizationShowcase.jsx":"c27ebb62e810","ui_kits/technology-site-clm/TechnologySiteCLM.jsx":"7d565ede9032","ui_kits/technology-site-clm/TechnologySiteCLMMobile.jsx":"cb42d627a1bd","ui_kits/technology-site-clm/data.js":"8f35bb788e7c"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.CLevelInsightDesignSystem_27a32f = window.CLevelInsightDesignSystem_27a32f || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// assets/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "assets/image-slot.js", error: String((e && e.message) || e) }); }

// components/core/Band.jsx
try { (() => {
const tones = {
  paper: {
    background: "var(--surface-page)"
  },
  paperGrid: {
    background: "var(--surface-page)",
    backgroundImage: "var(--grid-paper)",
    backgroundSize: "var(--grid-repeat)"
  },
  card: {
    background: "var(--surface-page-alt)"
  },
  dossier: {
    background: "var(--surface-dossier)",
    color: "var(--text-on-dossier)"
  },
  dossierGrid: {
    background: "var(--surface-dossier-deep)",
    backgroundImage: "var(--grid-dossier)",
    backgroundSize: "var(--grid-repeat)",
    color: "var(--text-on-dossier)"
  }
};
/** Full-width layout band with a ruled head. The system's structural unit - not a card. */
function Band({
  tone = "paper",
  id,
  eyebrow,
  title,
  aside,
  width = "container",
  tight,
  children,
  style
}) {
  const dark = tone.startsWith("dossier");
  const max = width === "wide" ? "var(--container-wide)" : width === "narrow" ? "var(--container-narrow)" : "var(--container)";
  return React.createElement("section", {
    id,
    style: {
      paddingTop: tight ? "var(--band-py-tight)" : "var(--band-py)",
      paddingBottom: tight ? "var(--band-py-tight)" : "var(--band-py)",
      ...tones[tone],
      ...style
    }
  }, React.createElement("div", {
    style: {
      maxWidth: max,
      margin: "0 auto",
      padding: "0 var(--gutter-desktop)"
    }
  }, eyebrow || title || aside ? React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: aside ? "1fr auto" : "1fr",
      gap: "var(--space-8)",
      alignItems: "end",
      paddingBottom: "var(--space-4)",
      marginBottom: "var(--space-10)",
      borderBottom: dark ? "2px solid var(--line-on-dossier)" : "2px solid var(--line-strong)"
    }
  }, React.createElement("div", null, eyebrow ? React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: dark ? "var(--accent-tech)" : "var(--text-muted)"
    }
  }, eyebrow) : null, title ? React.createElement("h2", {
    style: {
      marginTop: "var(--space-3)",
      maxWidth: "26ch",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)"
    }
  }, title) : null), aside ? React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)",
      whiteSpace: "nowrap"
    }
  }, aside) : null) : null, children));
}
Object.assign(__ds_scope, { Band });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Band.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
const base = {
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  gap: "var(--space-2)",
  minHeight: "var(--touch-min)",
  padding: "0 var(--space-6)",
  fontFamily: "var(--font-sans)",
  fontSize: "var(--text-small)",
  fontWeight: "var(--weight-semibold)",
  lineHeight: 1,
  border: "1px solid transparent",
  borderRadius: "var(--radius-xs)",
  cursor: "pointer",
  textDecoration: "none",
  transition: "var(--transition-control)",
  whiteSpace: "nowrap"
};
const skins = {
  primary: {
    background: "var(--cli-navy-800)",
    color: "var(--cli-paper-200)"
  },
  accent: {
    background: "var(--accent-tech)",
    color: "#fff"
  },
  ghost: {
    background: "transparent",
    color: "var(--cli-navy-800)",
    borderColor: "var(--cli-navy-800)"
  },
  onDark: {
    background: "var(--cli-paper-200)",
    color: "var(--cli-navy-800)"
  },
  onDarkLine: {
    background: "transparent",
    color: "var(--cli-paper-200)",
    borderColor: "var(--line-on-dossier)"
  },
  quiet: {
    background: "transparent",
    color: "var(--text-muted)",
    padding: 0,
    minHeight: "var(--touch-min)"
  }
};
const sizes = {
  sm: {
    minHeight: "36px",
    padding: "0 var(--space-4)",
    fontSize: "var(--text-label-size)"
  },
  md: {},
  lg: {
    minHeight: "52px",
    padding: "0 var(--space-8)",
    fontSize: "var(--text-body-size)"
  }
};

/** Primary action control. Rectangular by system rule - never pill-shaped. */
function Button({
  variant = "primary",
  size = "md",
  href,
  children,
  disabled,
  trailing,
  style,
  ...rest
}) {
  const Tag = href && !disabled ? "a" : "button";
  const s = {
    ...base,
    ...sizes[size],
    ...skins[variant],
    ...(disabled ? {
      opacity: .5,
      cursor: "not-allowed"
    } : null),
    ...style
  };
  return React.createElement(Tag, {
    href: href && !disabled ? href : undefined,
    disabled: Tag === "button" ? disabled : undefined,
    style: s,
    ...rest
  }, children, trailing ? React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "1em",
      opacity: .8
    }
  }, trailing) : null);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/conversion/CTABlock.jsx
try { (() => {
/** Final CTA band on the paid Diagnostics. A full band, never a small card. */
function CTABlock({
  eyebrow = "Первый платный вход",
  title,
  body,
  primaryCta = {
    label: "Запросить Диагностику",
    href: "#diagnostics"
  },
  secondaryCta,
  terms = [],
  tone = "dossier",
  scene
}) {
  const dark = tone !== "paper";
  return React.createElement("section", {
    style: {
      position: "relative",
      overflow: "hidden",
      isolation: "isolate",
      ...(dark ? {
        background: "var(--surface-dossier-deep)",
        backgroundImage: scene ? "none" : "var(--grid-dossier)",
        backgroundSize: "var(--grid-repeat)",
        color: "var(--text-on-dossier)"
      } : {
        background: "var(--surface-page)",
        backgroundImage: "var(--grid-paper)",
        backgroundSize: "var(--grid-repeat)"
      })
    }
  }, scene ? React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 0
    }
  }, scene) : null, scene ? React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 1,
      background: "var(--scrim-bottom)",
      pointerEvents: "none"
    }
  }) : null, React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2,
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "var(--band-py-tight) var(--gutter-desktop)",
      display: "grid",
      gridTemplateColumns: "1.3fr 1fr",
      gap: "var(--space-16)",
      alignItems: "end"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--accent-tech)"
    }
  }, eyebrow), React.createElement("h2", {
    style: {
      marginTop: "var(--space-4)",
      fontSize: "var(--text-h1)",
      lineHeight: "var(--leading-display)",
      maxWidth: "22ch",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)"
    }
  }, title), body ? React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      fontSize: "var(--text-lead)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)",
      maxWidth: "48ch"
    }
  }, body) : null, React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      marginTop: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, React.createElement(__ds_scope.Button, {
    variant: dark ? "onDark" : "primary",
    size: "lg",
    href: primaryCta.href
  }, primaryCta.label), secondaryCta ? React.createElement(__ds_scope.Button, {
    variant: dark ? "onDarkLine" : "ghost",
    size: "lg",
    href: secondaryCta.href
  }, secondaryCta.label) : null)), terms.length ? React.createElement("div", {
    style: {
      borderTop: dark ? "1px solid var(--line-on-dossier)" : "1px solid var(--line-hairline)",
      paddingTop: "var(--space-4)",
      display: "grid",
      gap: "var(--space-3)"
    }
  }, terms.map((t, i) => React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "22px 1fr",
      gap: "var(--space-3)",
      fontSize: "var(--text-small)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      color: "var(--accent-tech)"
    }
  }, String(i + 1).padStart(2, "0")), React.createElement("span", null, t)))) : null));
}
Object.assign(__ds_scope, { CTABlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/conversion/CTABlock.jsx", error: String((e && e.message) || e) }); }

// components/conversion/RequestDiagnosticsForm.jsx
try { (() => {
const label = {
  display: "block",
  fontFamily: "var(--font-mono)",
  fontSize: "var(--text-micro)",
  letterSpacing: ".1em",
  textTransform: "uppercase",
  color: "var(--text-label)",
  marginBottom: "var(--space-2)"
};
const field = {
  width: "100%",
  minHeight: "var(--touch-min)",
  padding: "var(--space-3) var(--space-4)",
  background: "var(--cli-white)",
  border: "1px solid var(--line-hairline)",
  borderRadius: "var(--radius-xs)",
  fontFamily: "var(--font-sans)",
  fontSize: "var(--text-body-size)",
  color: "var(--text-body)",
  boxSizing: "border-box"
};
/** Short Diagnostics request. Visible labels, six fields, no on-site diagnosis. */
function RequestDiagnosticsForm({
  title = "Заявка на Диагностику",
  note,
  onSubmit,
  submitLabel = "Отправить заявку",
  state = "idle",
  errors = {},
  consentText = "Согласен на обработку персональных данных."
}) {
  const err = k => errors[k] ? React.createElement("span", {
    style: {
      display: "block",
      marginTop: "6px",
      fontSize: "var(--text-small)",
      color: "var(--role-stop)"
    }
  }, errors[k]) : null;
  return React.createElement("form", {
    onSubmit,
    noValidate: true,
    style: {
      border: "2px solid var(--line-strong)",
      background: "var(--surface-card)",
      padding: "var(--space-8)",
      display: "grid",
      gap: "var(--space-5)",
      maxWidth: "620px"
    }
  }, React.createElement("div", null, React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)"
    }
  }, title), note ? React.createElement("p", {
    style: {
      marginTop: "var(--space-3)",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, note) : null), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-5)"
    }
  }, React.createElement("div", null, React.createElement("label", {
    htmlFor: "rd-name",
    style: label
  }, "Имя"), React.createElement("input", {
    id: "rd-name",
    name: "name",
    style: {
      ...field,
      borderColor: errors.name ? "var(--role-stop)" : "var(--line-hairline)"
    },
    autoComplete: "name"
  }), err("name")), React.createElement("div", null, React.createElement("label", {
    htmlFor: "rd-company",
    style: label
  }, "Компания"), React.createElement("input", {
    id: "rd-company",
    name: "company",
    style: field,
    autoComplete: "organization"
  }), err("company"))), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "var(--space-5)"
    }
  }, React.createElement("div", null, React.createElement("label", {
    htmlFor: "rd-role",
    style: label
  }, "Роль"), React.createElement("input", {
    id: "rd-role",
    name: "role",
    style: field,
    placeholder: "CEO / COO / CFO"
  }), err("role")), React.createElement("div", null, React.createElement("label", {
    htmlFor: "rd-contact",
    style: label
  }, "Контакт"), React.createElement("input", {
    id: "rd-contact",
    name: "contact",
    style: {
      ...field,
      borderColor: errors.contact ? "var(--role-stop)" : "var(--line-hairline)"
    },
    placeholder: "E-mail или телефон"
  }), err("contact"))), React.createElement("div", null, React.createElement("label", {
    htmlFor: "rd-situation",
    style: label
  }, "Коротко о ситуации"), React.createElement("textarea", {
    id: "rd-situation",
    name: "situation",
    rows: 4,
    style: {
      ...field,
      minHeight: "120px",
      resize: "vertical"
    }
  }), React.createElement("span", {
    style: {
      display: "block",
      marginTop: "6px",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, "3-4 строки. Полная диагностика не проводится на сайте.")), React.createElement("label", {
    htmlFor: "rd-consent",
    style: {
      display: "grid",
      gridTemplateColumns: "20px 1fr",
      gap: "var(--space-3)",
      alignItems: "start",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      minHeight: "var(--touch-min)"
    }
  }, React.createElement("input", {
    id: "rd-consent",
    name: "consent",
    type: "checkbox",
    style: {
      width: "20px",
      height: "20px",
      accentColor: "var(--cli-navy-800)",
      marginTop: "2px"
    }
  }), React.createElement("span", null, consentText)), errors.consent ? React.createElement("span", {
    style: {
      fontSize: "var(--text-small)",
      color: "var(--role-stop)"
    }
  }, errors.consent) : null, React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-5)",
      flexWrap: "wrap"
    }
  }, React.createElement(__ds_scope.Button, {
    variant: "primary",
    size: "lg",
    disabled: state === "sending"
  }, state === "sending" ? "Отправляем…" : submitLabel), state === "sent" ? React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--role-go)"
    }
  }, "Заявка принята") : null));
}
Object.assign(__ds_scope, { RequestDiagnosticsForm });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/conversion/RequestDiagnosticsForm.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
const roles = {
  neutral: {
    color: "var(--text-muted)",
    borderColor: "var(--line-hairline)",
    background: "var(--cli-paper-200)"
  },
  route: {
    color: "var(--role-route)",
    borderColor: "var(--cli-copper-200)",
    background: "transparent"
  },
  data: {
    color: "var(--role-data)",
    borderColor: "var(--cli-teal-200)",
    background: "transparent"
  },
  stop: {
    color: "var(--role-stop)",
    borderColor: "var(--cli-red-200)",
    background: "transparent"
  },
  architecture: {
    color: "var(--role-architecture)",
    borderColor: "var(--cli-navy-800)",
    background: "transparent"
  },
  onDark: {
    color: "var(--cli-paper-200)",
    borderColor: "var(--line-on-dossier)",
    background: "transparent"
  }
};
/** Mono uppercase role label. Always names the meaning that a colour alone must not carry. */
function Tag({
  role = "neutral",
  children,
  style,
  ...rest
}) {
  return React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      padding: "5px 9px",
      border: "1px solid",
      borderRadius: "var(--radius-xs)",
      ...roles[role],
      ...style
    },
    ...rest
  }, children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// components/evidence/CaseCard.jsx
try { (() => {
/** Case as proof of applicability: situation → unmanageable → technology → first step → became manageable. */
function CaseCard({
  sector,
  scale,
  situation,
  unmanageable,
  technology,
  firstStep,
  result,
  href,
  linkLabel = "Смотреть кейс"
}) {
  const rows = [["Ситуация", situation, null], ["Было неуправляемым", unmanageable, "stop"], ["Технология", technology, null], ["Первый шаг", firstStep, "route"], ["Стало управляемым", result, "go"]];
  const tone = {
    stop: "var(--role-stop)",
    route: "var(--role-route)",
    go: "var(--role-go)"
  };
  return React.createElement("article", {
    style: {
      border: "1px solid var(--cli-paper-500)",
      background: "var(--surface-card)",
      boxShadow: "var(--shadow-card)",
      display: "grid",
      alignContent: "start"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      padding: "var(--space-3) var(--space-5)",
      borderBottom: "1px solid var(--cli-paper-500)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, React.createElement("span", null, sector), scale ? React.createElement("span", null, scale) : null), React.createElement("div", {
    style: {
      padding: "var(--space-5)",
      display: "grid",
      gap: "var(--space-4)"
    }
  }, rows.filter(r => r[1]).map(([label, text, t]) => React.createElement("div", {
    key: label,
    style: {
      display: "grid",
      gridTemplateColumns: "146px 1fr",
      gap: "var(--space-4)",
      alignItems: "baseline"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: t ? tone[t] : "var(--text-muted)"
    }
  }, label), React.createElement("p", {
    style: {
      fontSize: "var(--text-small)",
      color: "var(--text-body)"
    }
  }, text)))), href ? React.createElement("a", {
    href,
    style: {
      padding: "var(--space-4) var(--space-5)",
      borderTop: "1px solid var(--cli-paper-500)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--cli-navy-800)",
      textDecoration: "none",
      border: 0,
      borderTop: "1px solid var(--cli-paper-500)",
      minHeight: "var(--touch-min)",
      display: "flex",
      alignItems: "center"
    }
  }, linkLabel + " →") : null);
}
Object.assign(__ds_scope, { CaseCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/CaseCard.jsx", error: String((e && e.message) || e) }); }

// components/evidence/CaseFlow.jsx
try { (() => {
/** Case as a horizontal / vertical flow of managerial states. Dark band form of CaseCard. */
function CaseFlow({
  steps = [],
  tone = "dossier",
  aside
}) {
  const dark = tone === "dossier";
  const accent = {
    gap: "#e79a9a",
    go: "#7fc9c0"
  };
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: aside ? "minmax(280px,34%) 1fr" : "1fr",
      gap: "var(--space-12)",
      alignItems: "stretch"
    }
  }, aside || null, React.createElement("div", {
    style: {
      display: "grid",
      gap: "1px",
      background: dark ? "var(--line-on-dossier)" : "var(--cli-paper-500)",
      alignContent: "start"
    }
  }, steps.map((s, i) => React.createElement("div", {
    key: i,
    style: {
      background: dark ? "var(--cli-navy-800)" : "var(--surface-card)",
      padding: "var(--space-5) var(--space-6)",
      display: "grid",
      gridTemplateColumns: "150px 1fr",
      gap: "var(--space-6)",
      alignItems: "baseline"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: s.state ? accent[s.state] : dark ? "var(--cli-slate-300)" : "var(--text-muted)"
    }
  }, s.label), React.createElement("p", {
    style: {
      fontSize: "var(--text-small)",
      color: dark ? "rgba(243,235,221,.88)" : "var(--text-body)"
    }
  }, s.text)))));
}
Object.assign(__ds_scope, { CaseFlow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/CaseFlow.jsx", error: String((e && e.message) || e) }); }

// components/evidence/MaterialCard.jsx
try { (() => {
/** Material / artefact row: presentation, one-page, schema pack, article. */
function MaterialCard({
  kind = "PDF",
  title,
  description,
  meta,
  href,
  actionLabel = "Скачать"
}) {
  return React.createElement("a", {
    href,
    style: {
      display: "grid",
      gridTemplateColumns: "auto 1fr auto",
      gap: "var(--space-6)",
      alignItems: "center",
      padding: "var(--space-5) var(--space-6)",
      background: "var(--surface-card)",
      border: "1px solid var(--cli-paper-500)",
      textDecoration: "none",
      color: "inherit",
      minHeight: "var(--touch-min)",
      transition: "var(--transition-control)"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--accent-tech)",
      border: "1px solid var(--cli-copper-200)",
      padding: "6px 9px",
      whiteSpace: "nowrap"
    }
  }, kind), React.createElement("span", null, React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h4)",
      color: "var(--text-display)"
    }
  }, title), description ? React.createElement("span", {
    style: {
      display: "block",
      marginTop: "4px",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      maxWidth: "64ch"
    }
  }, description) : null), React.createElement("span", {
    style: {
      display: "grid",
      justifyItems: "end",
      gap: "4px"
    }
  }, meta ? React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, meta) : null, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--cli-navy-800)"
    }
  }, actionLabel + " ↓")));
}
Object.assign(__ds_scope, { MaterialCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/MaterialCard.jsx", error: String((e && e.message) || e) }); }

// components/evidence/OnePageBlock.jsx
try { (() => {
/** One-page / presentation download band: an artefact offer, not a lead magnet. */
function OnePageBlock({
  title,
  description,
  bullets = [],
  ctaLabel = "Получить one-page",
  ctaHref = "#one-page",
  secondary,
  preview,
  tone = "paper"
}) {
  const dark = tone === "dossier";
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: preview ? "1fr minmax(260px,34%)" : "1fr",
      gap: "var(--space-12)",
      alignItems: "center",
      padding: "var(--space-8)",
      border: dark ? "1px solid var(--line-on-dossier)" : "2px solid var(--line-strong)",
      background: dark ? "var(--surface-dossier-raised)" : "var(--surface-card)"
    }
  }, React.createElement("div", null, React.createElement("h3", {
    style: {
      fontSize: "var(--text-h3)",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)",
      maxWidth: "26ch"
    }
  }, title), description ? React.createElement("p", {
    style: {
      marginTop: "var(--space-4)",
      fontSize: "var(--text-body-size)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)",
      maxWidth: "58ch"
    }
  }, description) : null, bullets.length ? React.createElement("ul", {
    style: {
      margin: "var(--space-5) 0 0",
      padding: 0,
      listStyle: "none",
      display: "grid",
      gap: "var(--space-2)"
    }
  }, bullets.map((b, i) => React.createElement("li", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "18px 1fr",
      gap: "var(--space-3)",
      fontSize: "var(--text-small)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      color: "var(--accent-tech)"
    }
  }, "→"), React.createElement("span", null, b)))) : null, React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      marginTop: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, React.createElement(__ds_scope.Button, {
    variant: dark ? "onDark" : "primary",
    href: ctaHref,
    trailing: "↓"
  }, ctaLabel), secondary ? React.createElement(__ds_scope.Button, {
    variant: dark ? "onDarkLine" : "ghost",
    href: secondary.href
  }, secondary.label) : null)), preview || null);
}
Object.assign(__ds_scope, { OnePageBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/evidence/OnePageBlock.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Footer.jsx
try { (() => {
/** Site footer: links back to the gigasite, the author layer, materials and the 7-technology map. */
function Footer({
  platform = "C-Level Insight",
  technology = "Управление Директорами / CLM",
  columns = [],
  technologies = [],
  note
}) {
  return React.createElement("footer", {
    style: {
      background: "var(--surface-dossier-deep)",
      backgroundImage: "var(--grid-dossier)",
      backgroundSize: "var(--grid-repeat)",
      color: "var(--text-on-dossier)",
      paddingTop: "var(--space-16)",
      paddingBottom: "var(--space-10)"
    }
  }, React.createElement("div", {
    style: {
      maxWidth: "var(--container-wide)",
      margin: "0 auto",
      padding: "0 var(--gutter-desktop)"
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(240px,1fr) 2fr",
      gap: "var(--space-16)",
      paddingBottom: "var(--space-10)",
      borderBottom: "1px solid var(--line-on-dossier)"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h4)",
      color: "var(--cli-paper-200)"
    }
  }, platform), React.createElement("div", {
    style: {
      marginTop: "6px",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--accent-tech)"
    }
  }, technology), note ? React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      fontSize: "var(--text-small)",
      color: "var(--text-on-dossier-muted)",
      maxWidth: "34ch"
    }
  }, note) : null), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(150px,1fr))",
      gap: "var(--space-8)"
    }
  }, columns.map(c => React.createElement("div", {
    key: c.title
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--cli-slate-300)",
      marginBottom: "var(--space-4)"
    }
  }, c.title), React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-1)"
    }
  }, c.links.map(l => React.createElement("a", {
    key: l.label,
    href: l.href,
    style: {
      fontSize: "var(--text-small)",
      color: "var(--cli-paper-200)",
      textDecoration: "none",
      border: 0,
      minHeight: "var(--touch-min)",
      display: "flex",
      alignItems: "center"
    }
  }, l.label))))))), technologies.length ? React.createElement("div", {
    style: {
      paddingTop: "var(--space-8)"
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--cli-slate-300)",
      marginBottom: "var(--space-4)"
    }
  }, "Карта технологий · 7"), React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(170px,1fr))",
      gap: "1px",
      background: "var(--line-on-dossier)"
    }
  }, technologies.map(t => React.createElement("a", {
    key: t.name,
    href: t.href,
    style: {
      background: t.active ? "var(--cli-paper-200)" : "var(--cli-navy-800)",
      color: t.active ? "var(--cli-navy-800)" : "var(--cli-paper-200)",
      textDecoration: "none",
      border: 0,
      padding: "var(--space-4)",
      minHeight: "var(--touch-min)",
      display: "grid",
      gap: "4px",
      alignContent: "center"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: ".1em",
      color: t.active ? "var(--accent-tech)" : "var(--cli-slate-300)"
    }
  }, t.index), React.createElement("span", {
    style: {
      fontSize: "var(--text-small)",
      fontWeight: "var(--weight-medium)"
    }
  }, t.name))))) : null));
}
Object.assign(__ds_scope, { Footer });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Footer.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Header.jsx
try { (() => {
/** Technology-site header: platform mark, technology name, section links, Diagnostics CTA. */
function Header({
  technology = "Управление Директорами / CLM",
  index = "04",
  platform = "C-Level Insight",
  links = [],
  ctaLabel = "Запросить Диагностику",
  ctaHref = "#diagnostics",
  tone = "paper"
}) {
  const dark = tone === "dossier";
  return React.createElement("header", {
    style: {
      background: dark ? "var(--surface-dossier)" : "var(--surface-page)",
      borderBottom: dark ? "1px solid var(--line-on-dossier)" : "1px solid var(--line-hairline)",
      position: "relative"
    }
  }, React.createElement("div", {
    style: {
      maxWidth: "var(--container-wide)",
      margin: "0 auto",
      padding: "18px var(--gutter-desktop)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, React.createElement("a", {
    href: "#top",
    style: {
      textDecoration: "none",
      border: 0,
      display: "block"
    }
  }, React.createElement("span", {
    style: {
      display: "block",
      fontFamily: "var(--font-display)",
      fontSize: "18px",
      fontWeight: "var(--weight-bold)",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)"
    }
  }, technology), React.createElement("span", {
    style: {
      display: "block",
      marginTop: "4px",
      fontFamily: "var(--font-mono)",
      fontSize: "10px",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--accent-tech)"
    }
  }, platform + " · ТЕХНОЛОГИЯ " + index)), React.createElement("nav", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "var(--space-6)",
      flexWrap: "wrap"
    }
  }, links.map(l => React.createElement("a", {
    key: l.label,
    href: l.href,
    style: {
      fontSize: "var(--text-small)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)",
      textDecoration: "none",
      border: 0,
      minHeight: "var(--touch-min)",
      display: "inline-flex",
      alignItems: "center"
    }
  }, l.label)), React.createElement(__ds_scope.Button, {
    variant: dark ? "onDark" : "primary",
    href: ctaHref
  }, ctaLabel))));
}
Object.assign(__ds_scope, { Header });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Header.jsx", error: String((e && e.message) || e) }); }

// components/navigation/StickySectionNav.jsx
try { (() => {
/** Sticky rail marking the reader's position on a long technology page. */
function StickySectionNav({
  items = [],
  activeId,
  onSelect,
  orientation = "vertical",
  label = "Разделы страницы"
}) {
  const horizontal = orientation === "horizontal";
  return React.createElement("nav", {
    "aria-label": label,
    style: horizontal ? {
      position: "sticky",
      top: 0,
      zIndex: 5,
      display: "flex",
      gap: 0,
      overflowX: "auto",
      background: "var(--surface-page)",
      borderBottom: "1px solid var(--line-hairline)"
    } : {
      position: "sticky",
      top: "var(--space-8)",
      display: "grid",
      gap: "2px",
      borderLeft: "2px solid var(--line-hairline)"
    }
  }, items.map(it => {
    const active = it.id === activeId;
    return React.createElement("a", {
      key: it.id,
      href: "#" + it.id,
      "aria-current": active ? "true" : undefined,
      onClick: onSelect ? e => {
        e.preventDefault();
        onSelect(it.id);
      } : undefined,
      style: {
        display: "flex",
        alignItems: "center",
        minHeight: "var(--touch-min)",
        padding: horizontal ? "0 var(--space-5)" : "10px var(--space-4)",
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-micro)",
        letterSpacing: ".1em",
        textTransform: "uppercase",
        whiteSpace: "nowrap",
        textDecoration: "none",
        color: active ? "var(--cli-navy-800)" : "var(--text-muted)",
        background: active && !horizontal ? "var(--cli-paper-100)" : "transparent",
        border: 0,
        marginLeft: horizontal ? 0 : "-2px",
        borderLeft: horizontal ? "none" : "2px solid " + (active ? "var(--accent-tech)" : "transparent"),
        borderBottom: horizontal ? "2px solid " + (active ? "var(--accent-tech)" : "transparent") : "none",
        transition: "var(--transition-control)"
      }
    }, it.label);
  }));
}
Object.assign(__ds_scope, { StickySectionNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/StickySectionNav.jsx", error: String((e && e.message) || e) }); }

// components/positioning/ComparisonMatrix.jsx
try { (() => {
/** Comparison matrix: technologies, options or before/after states as a ruled dossier table. */
function ComparisonMatrix({
  columns = [],
  rows = [],
  highlightColumn,
  caption
}) {
  const cellPad = "11px var(--space-4)";
  return React.createElement("div", null, React.createElement("table", {
    style: {
      width: "100%",
      borderCollapse: "collapse",
      background: "var(--surface-card)",
      border: "2px solid var(--line-strong)"
    }
  }, React.createElement("thead", null, React.createElement("tr", null, React.createElement("th", {
    style: {
      textAlign: "left",
      padding: cellPad,
      background: "var(--surface-dossier)",
      color: "#e8b39a",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      fontWeight: "var(--weight-medium)",
      width: "26%"
    }
  }, columns[0] || ""), columns.slice(1).map((c, i) => React.createElement("th", {
    key: c,
    style: {
      textAlign: "left",
      padding: cellPad,
      background: "var(--surface-dossier)",
      color: "var(--cli-paper-200)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      fontWeight: "var(--weight-medium)",
      borderBottom: highlightColumn === i + 1 ? "3px solid var(--accent-tech)" : "none"
    }
  }, c)))), React.createElement("tbody", null, rows.map((r, ri) => React.createElement("tr", {
    key: ri
  }, React.createElement("th", {
    style: {
      textAlign: "left",
      padding: cellPad,
      borderBottom: ri < rows.length - 1 ? "1px solid var(--cli-paper-400)" : "none",
      fontSize: "var(--text-small)",
      fontWeight: "var(--weight-medium)",
      verticalAlign: "top"
    }
  }, r.label), r.cells.map((c, ci) => React.createElement("td", {
    key: ci,
    style: {
      padding: cellPad,
      borderBottom: ri < rows.length - 1 ? "1px solid var(--cli-paper-400)" : "none",
      fontSize: "var(--text-small)",
      verticalAlign: "top",
      color: c && c.tone === "stop" ? "var(--cli-red-700)" : c && c.tone === "go" ? "var(--cli-teal-700)" : "var(--text-body)",
      background: highlightColumn === ci + 1 ? "var(--cli-paper-200)" : "transparent",
      fontWeight: c && c.strong ? "var(--weight-semibold)" : "var(--weight-regular)"
    }
  }, c && typeof c === "object" ? c.text : c)))))), caption ? React.createElement("p", {
    style: {
      marginTop: "var(--space-4)",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      maxWidth: "var(--measure-body)"
    }
  }, caption) : null);
}
Object.assign(__ds_scope, { ComparisonMatrix });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/positioning/ComparisonMatrix.jsx", error: String((e && e.message) || e) }); }

// components/positioning/WhatItIsNot.jsx
try { (() => {
/** "Что это / что это не": the anti-category block. Removes a false category without arguing with the market. */
function WhatItIsNot({
  isNot = [],
  isThis = [],
  formula,
  tone = "paper"
}) {
  const dark = tone === "dossier";
  const rows = Math.max(isNot.length, isThis.length);
  const cell = {
    padding: "var(--space-5) var(--space-6)"
  };
  const line = dark ? "1px solid var(--line-on-dossier)" : "1px solid var(--cli-paper-500)";
  return React.createElement("div", null, formula ? React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h3)",
      lineHeight: "var(--leading-title)",
      maxWidth: "34ch",
      marginBottom: "var(--space-8)",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)"
    }
  }, formula) : null, React.createElement("div", {
    style: {
      border: dark ? "1px solid var(--line-on-dossier)" : "2px solid var(--line-strong)",
      background: dark ? "var(--surface-dossier-raised)" : "var(--surface-card)"
    }
  }, React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr"
    }
  }, React.createElement("div", {
    style: {
      ...cell,
      paddingTop: "var(--space-3)",
      paddingBottom: "var(--space-3)",
      background: dark ? "transparent" : "var(--surface-dossier)",
      color: "#e8b39a",
      borderRight: line,
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase"
    }
  }, "Это не"), React.createElement("div", {
    style: {
      ...cell,
      paddingTop: "var(--space-3)",
      paddingBottom: "var(--space-3)",
      background: dark ? "transparent" : "var(--surface-dossier)",
      color: "var(--cli-paper-200)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase"
    }
  }, "Правильная категория")), Array.from({
    length: rows
  }).map((_, i) => React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      borderTop: line
    }
  }, React.createElement("div", {
    style: {
      ...cell,
      borderRight: line
    }
  }, isNot[i] ? [React.createElement("strong", {
    key: "t",
    style: {
      display: "block",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--role-stop)",
      marginBottom: "6px",
      fontWeight: 400
    }
  }, isNot[i].title), React.createElement("p", {
    key: "p",
    style: {
      fontSize: "var(--text-small)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--cli-red-700)"
    }
  }, isNot[i].text)] : null), React.createElement("div", {
    style: cell
  }, isThis[i] ? [React.createElement("strong", {
    key: "t",
    style: {
      display: "block",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--role-data)",
      marginBottom: "6px",
      fontWeight: 400
    }
  }, isThis[i].title), React.createElement("p", {
    key: "p",
    style: {
      fontSize: "var(--text-small)",
      color: dark ? "var(--cli-paper-200)" : "var(--text-body)"
    }
  }, isThis[i].text)] : null)))));
}
Object.assign(__ds_scope, { WhatItIsNot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/positioning/WhatItIsNot.jsx", error: String((e && e.message) || e) }); }

// components/sections/OpportunityBlock.jsx
try { (() => {
/** "What the technology opens": 2-4 opportunities as equal cells in one band, plus an optional vertical accordion. */
function OpportunityBlock({
  items = [],
  mode = "cells",
  openId,
  onToggle
}) {
  if (mode === "accordion") return React.createElement("div", {
    style: {
      borderTop: "2px solid var(--line-strong)"
    }
  }, items.map((it, i) => {
    const open = openId ? it.id === openId : i === 0;
    return React.createElement("div", {
      key: it.id || it.title,
      style: {
        borderBottom: "1px solid var(--line-hairline)",
        background: "var(--surface-card)"
      }
    }, React.createElement("button", {
      type: "button",
      onClick: onToggle ? () => onToggle(it.id) : undefined,
      "aria-expanded": open,
      style: {
        width: "100%",
        appearance: "none",
        background: "transparent",
        border: 0,
        cursor: "pointer",
        textAlign: "left",
        display: "grid",
        gridTemplateColumns: "48px 1fr 24px",
        gap: "var(--space-4)",
        alignItems: "center",
        padding: "var(--space-5) var(--space-6)",
        minHeight: "var(--touch-min)"
      }
    }, React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-micro)",
        letterSpacing: ".1em",
        color: "var(--accent-tech)"
      }
    }, String(i + 1).padStart(2, "0")), React.createElement("span", {
      style: {
        fontFamily: "var(--font-display)",
        fontSize: "var(--text-h4)",
        color: "var(--text-display)"
      }
    }, it.title), React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: "18px",
        color: "var(--text-muted)"
      }
    }, open ? "–" : "+")), open ? React.createElement("div", {
      style: {
        padding: "0 var(--space-6) var(--space-6) calc(var(--space-6) + 48px + var(--space-4))",
        maxWidth: "70ch"
      }
    }, React.createElement("p", {
      style: {
        fontSize: "var(--text-small)",
        color: "var(--text-muted)"
      }
    }, it.text)) : null);
  }));
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(240px,1fr))",
      gap: 0,
      border: "1px solid var(--line-hairline)",
      background: "var(--surface-card)"
    }
  }, items.map((it, i) => React.createElement("div", {
    key: it.title,
    style: {
      padding: "var(--space-6)",
      borderRight: i < items.length - 1 ? "1px solid var(--line-hairline)" : "none",
      display: "grid",
      gap: "var(--space-3)",
      alignContent: "start",
      position: "relative"
    }
  }, React.createElement("span", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: "3px",
      background: "var(--accent-tech)"
    }
  }), React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      color: "var(--text-muted)"
    }
  }, String(i + 1).padStart(2, "0")), React.createElement("h3", {
    style: {
      fontSize: "var(--text-h4)"
    }
  }, it.title), React.createElement("p", {
    style: {
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, it.text))));
}
Object.assign(__ds_scope, { OpportunityBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/OpportunityBlock.jsx", error: String((e && e.message) || e) }); }

// components/sections/SituationBlock.jsx
try { (() => {
/** "Когда уместна": situations in which the technology applies, as a ruled list with route markers. */
function SituationBlock({
  situations = [],
  notApplicable = []
}) {
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: notApplicable.length ? "1.35fr 1fr" : "1fr",
      gap: "var(--space-12)",
      alignItems: "start"
    }
  }, React.createElement("div", null, React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--role-route)",
      marginBottom: "var(--space-4)"
    }
  }, "Уместна, когда"), React.createElement("div", {
    style: {
      borderTop: "1px solid var(--line-hairline)"
    }
  }, situations.map((s, i) => React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "26px 1fr",
      gap: "var(--space-4)",
      padding: "var(--space-4) 0",
      borderBottom: "1px solid var(--line-hairline)"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      color: "var(--role-route)"
    }
  }, "→"), React.createElement("p", {
    style: {
      fontSize: "var(--text-body-size)",
      maxWidth: "58ch"
    }
  }, s))))), notApplicable.length ? React.createElement("div", {
    style: {
      border: "1px solid var(--cli-red-200)",
      background: "var(--surface-card)",
      padding: "var(--space-6)"
    }
  }, React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--role-stop)",
      marginBottom: "var(--space-4)"
    }
  }, "Не время для технологии"), React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-3)"
    }
  }, notApplicable.map((s, i) => React.createElement("p", {
    key: i,
    style: {
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, s)))) : null);
}
Object.assign(__ds_scope, { SituationBlock });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/SituationBlock.jsx", error: String((e && e.message) || e) }); }

// components/sections/TechnologyHero.jsx
try { (() => {
/**
 * First screen of a technology site. Three dramaturgies:
 * schema (the visualization IS the hero object), map (7-technology control panel), scene (full-bleed image + scrim).
 */
function TechnologyHero({
  variant = "schema",
  eyebrow,
  title,
  formula,
  primaryCta = {
    label: "Запросить Диагностику",
    href: "#diagnostics"
  },
  secondaryCta = {
    label: "Посмотреть, как работает",
    href: "#how"
  },
  notes = [],
  visualization,
  children,
  nextHint
}) {
  const dark = variant !== "schema";
  const head = React.createElement("div", null, eyebrow ? React.createElement("div", {
    style: dark ? {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--accent-tech)",
      display: "flex",
      alignItems: "center",
      gap: "12px"
    } : {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      display: "inline-block",
      paddingBottom: "10px",
      borderBottom: "2px solid var(--accent-tech)"
    }
  }, dark ? [React.createElement("i", {
    key: "i",
    style: {
      width: "40px",
      height: "2px",
      background: "var(--accent-tech)",
      display: "block"
    }
  }), eyebrow] : eyebrow) : null, React.createElement("h1", {
    style: {
      fontSize: variant === "scene" ? "var(--text-hero-lg)" : "var(--text-hero)",
      lineHeight: "var(--leading-display)",
      margin: "var(--space-6) 0 0",
      maxWidth: "16ch",
      color: dark ? "var(--cli-paper-200)" : "var(--text-display)",
      textWrap: "balance"
    }
  }, title), formula ? React.createElement("p", {
    style: {
      marginTop: "var(--space-5)",
      fontSize: "var(--text-lead)",
      lineHeight: 1.55,
      maxWidth: "46ch",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--cli-slate-600)"
    }
  }, formula) : null, React.createElement("div", {
    style: {
      display: "flex",
      gap: "var(--space-3)",
      marginTop: "var(--space-8)",
      flexWrap: "wrap"
    }
  }, React.createElement(__ds_scope.Button, {
    variant: variant === "scene" ? "onDark" : dark ? "accent" : "primary",
    href: primaryCta.href
  }, primaryCta.label), secondaryCta ? React.createElement(__ds_scope.Button, {
    variant: dark ? "onDarkLine" : "ghost",
    href: secondaryCta.href,
    trailing: "→"
  }, secondaryCta.label) : null), notes.length ? React.createElement("div", {
    style: {
      marginTop: "var(--space-10)",
      borderTop: dark ? "1px solid var(--line-on-dossier)" : "1px solid var(--line-hairline)",
      paddingTop: "var(--space-4)",
      display: "grid",
      gap: "var(--space-3)"
    }
  }, notes.map((n, i) => React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "26px 1fr",
      gap: "var(--space-3)",
      fontSize: "var(--text-small)",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)"
    }
  }, React.createElement("b", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".08em",
      color: "var(--accent-tech)",
      fontWeight: 400,
      paddingTop: "2px"
    }
  }, String(i + 1).padStart(2, "0")), React.createElement("p", null, n)))) : null);
  if (variant === "scene") return React.createElement("section", {
    style: {
      position: "relative",
      minHeight: "var(--hero-min-h)",
      background: "var(--cli-navy-900)",
      overflow: "hidden",
      isolation: "isolate",
      display: "grid",
      alignItems: "end"
    }
  }, React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 0
    }
  }, children), React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 1,
      background: "var(--scrim-left)",
      pointerEvents: "none"
    }
  }), React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 1,
      background: "var(--scrim-bottom)",
      pointerEvents: "none"
    }
  }), React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2,
      maxWidth: "var(--container-wide)",
      width: "100%",
      margin: "0 auto",
      padding: "var(--space-24) var(--gutter-desktop) var(--space-16)"
    }
  }, React.createElement("div", {
    style: {
      maxWidth: "58ch"
    }
  }, head)));
  return React.createElement("section", {
    style: {
      position: "relative",
      minHeight: "var(--hero-min-h)",
      ...(dark ? {
        background: "var(--surface-dossier-deep)",
        backgroundImage: "var(--grid-dossier)",
        backgroundSize: "var(--grid-repeat)",
        color: "var(--text-on-dossier)"
      } : {
        background: "var(--surface-page)",
        backgroundImage: "var(--grid-paper)",
        backgroundSize: "var(--grid-repeat)"
      })
    }
  }, React.createElement("div", {
    style: {
      maxWidth: "var(--container-wide)",
      margin: "0 auto",
      padding: "var(--space-12) var(--gutter-desktop) var(--space-16)",
      display: "grid",
      gridTemplateColumns: "minmax(340px,38%) 1fr",
      gap: "var(--space-16)",
      alignItems: variant === "map" ? "center" : "start"
    }
  }, head, React.createElement("div", null, visualization || children)), nextHint ? React.createElement("div", {
    style: {
      maxWidth: "var(--container-wide)",
      margin: "0 auto",
      padding: "0 var(--gutter-desktop) var(--space-10)",
      display: "flex",
      alignItems: "center",
      gap: "var(--space-4)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)"
    }
  }, React.createElement("span", null, nextHint), React.createElement("i", {
    style: {
      flex: 1,
      height: "1px",
      background: dark ? "var(--line-on-dossier)" : "var(--line-hairline)"
    }
  })) : null);
}
Object.assign(__ds_scope, { TechnologyHero });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/TechnologyHero.jsx", error: String((e && e.message) || e) }); }

// components/sections/TechnologyIntro.jsx
try { (() => {
/** Editorial dossier intro: the technology's core stated once, with its layers listed as a ruled index. */
function TechnologyIntro({
  statement,
  body = [],
  layers = [],
  aside
}) {
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(320px,46%) 1fr",
      gap: "var(--space-16)",
      alignItems: "start"
    }
  }, React.createElement("div", null, React.createElement("p", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-h3)",
      lineHeight: "var(--leading-title)",
      color: "var(--text-display)",
      maxWidth: "26ch"
    }
  }, statement), body.map((p, i) => React.createElement("p", {
    key: i,
    style: {
      marginTop: "var(--space-5)",
      fontSize: "var(--text-body-size)",
      color: "var(--text-muted)",
      maxWidth: "var(--measure-body)"
    }
  }, p)), aside ? React.createElement("p", {
    style: {
      marginTop: "var(--space-8)",
      paddingLeft: "var(--space-5)",
      borderLeft: "2px solid var(--accent-tech)",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      maxWidth: "46ch"
    }
  }, aside) : null), layers.length ? React.createElement("div", {
    style: {
      borderTop: "2px solid var(--line-strong)"
    }
  }, layers.map((l, i) => React.createElement("div", {
    key: l.title,
    style: {
      display: "grid",
      gridTemplateColumns: "48px 1fr",
      gap: "var(--space-4)",
      padding: "var(--space-5) 0",
      borderBottom: "1px solid var(--line-hairline)",
      alignItems: "baseline"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      color: "var(--accent-tech)"
    }
  }, String(i + 1).padStart(2, "0")), React.createElement("div", null, React.createElement("h3", {
    style: {
      fontSize: "var(--text-h4)"
    }
  }, l.title), React.createElement("p", {
    style: {
      marginTop: "6px",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      maxWidth: "56ch"
    }
  }, l.text))))) : null);
}
Object.assign(__ds_scope, { TechnologyIntro });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/sections/TechnologyIntro.jsx", error: String((e && e.message) || e) }); }

// components/technology/MobileVisualizationPreview.jsx
try { (() => {
/** Mobile form of a schema: fixed 16:9 preview that opens full-screen instead of shrinking text to nothing. */
function MobileVisualizationPreview({
  item,
  open,
  onOpen,
  onClose,
  openLabel = "Открыть схему",
  closeLabel = "Закрыть"
}) {
  if (!item) return null;
  return React.createElement("div", null, React.createElement("figure", {
    style: {
      margin: 0,
      border: "1px solid var(--cli-paper-500)",
      background: "var(--surface-card)"
    }
  }, React.createElement("div", {
    style: {
      padding: "var(--space-3) var(--space-4)",
      borderBottom: "1px solid var(--cli-paper-500)",
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, item.title), React.createElement("div", {
    style: {
      aspectRatio: "var(--viz-ratio)",
      overflow: "hidden",
      background: "var(--surface-schema)"
    }
  }, React.createElement("img", {
    src: item.src,
    alt: item.alt,
    style: {
      width: "100%",
      display: "block"
    },
    loading: "lazy"
  })), React.createElement("figcaption", {
    style: {
      padding: "var(--space-4)",
      borderTop: "1px solid var(--cli-paper-500)",
      display: "grid",
      gap: "var(--space-4)"
    }
  }, React.createElement("p", {
    style: {
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, item.caption), React.createElement("button", {
    type: "button",
    onClick: onOpen,
    style: {
      appearance: "none",
      minHeight: "var(--touch-min)",
      padding: "0 var(--space-6)",
      background: "var(--cli-navy-800)",
      color: "var(--cli-paper-200)",
      border: 0,
      borderRadius: "var(--radius-xs)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-small)",
      fontWeight: "var(--weight-semibold)",
      cursor: "pointer",
      justifySelf: "start"
    }
  }, openLabel + " ↗"))), open ? React.createElement("div", {
    role: "dialog",
    "aria-modal": "true",
    style: {
      position: "fixed",
      inset: 0,
      zIndex: 50,
      background: "var(--surface-dossier-deep)",
      display: "grid",
      gridTemplateRows: "auto 1fr"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      alignItems: "center",
      gap: "var(--space-4)",
      padding: "var(--space-4)",
      borderBottom: "1px solid var(--line-on-dossier)"
    }
  }, React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "11px",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--cli-paper-200)"
    }
  }, item.title), React.createElement("button", {
    type: "button",
    onClick: onClose,
    style: {
      appearance: "none",
      minHeight: "var(--touch-min)",
      minWidth: "var(--touch-min)",
      background: "transparent",
      border: "1px solid var(--line-on-dossier)",
      color: "var(--cli-paper-200)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      cursor: "pointer",
      padding: "0 var(--space-4)"
    }
  }, closeLabel + " ×")), React.createElement("div", {
    style: {
      overflow: "auto",
      padding: "var(--space-4)",
      background: "var(--surface-schema)"
    }
  }, React.createElement("img", {
    src: item.src,
    alt: item.alt,
    style: {
      width: "260%",
      maxWidth: "none",
      display: "block"
    }
  }))) : null);
}
Object.assign(__ds_scope, { MobileVisualizationPreview });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/technology/MobileVisualizationPreview.jsx", error: String((e && e.message) || e) }); }

// components/technology/ProductLadder.jsx
try { (() => {
const edge = {
  entry: "var(--role-route)",
  build: "var(--role-architecture)",
  run: "var(--role-data)"
};
/** Диагностика → Сессия → Спринт 30-60-90 → Сопровождение. Identical on all 7 sites. */
function ProductLadder({
  steps = [],
  orientation = "horizontal",
  activeIndex,
  onSelect,
  tone = "paper"
}) {
  const dark = tone === "dossier";
  const vertical = orientation === "vertical";
  return React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: vertical ? "1fr" : "repeat(" + (steps.length || 4) + ",1fr)",
      gap: vertical ? "1px" : 0,
      background: dark ? "var(--line-on-dossier)" : "transparent",
      border: dark ? "none" : "1px solid var(--line-hairline)"
    }
  }, steps.map((s, i) => {
    const active = activeIndex === i;
    return React.createElement(onSelect ? "button" : "div", {
      key: s.title,
      type: onSelect ? "button" : undefined,
      onClick: onSelect ? () => onSelect(i) : undefined,
      style: {
        position: "relative",
        textAlign: "left",
        appearance: "none",
        cursor: onSelect ? "pointer" : "default",
        font: "inherit",
        background: dark ? active ? "var(--cli-navy-700)" : "var(--cli-navy-800)" : active ? "var(--cli-paper-200)" : "var(--surface-card)",
        color: dark ? "var(--text-on-dossier)" : "var(--text-body)",
        border: 0,
        borderRight: !vertical && i < steps.length - 1 ? dark ? "1px solid var(--line-on-dossier)" : "1px solid var(--line-hairline)" : "none",
        padding: "var(--space-6)",
        minHeight: "var(--touch-min)",
        display: "grid",
        gap: "var(--space-3)",
        alignContent: "start",
        transition: "var(--transition-control)"
      }
    }, React.createElement("span", {
      style: {
        position: "absolute",
        top: 0,
        left: 0,
        right: vertical ? "auto" : 0,
        bottom: vertical ? 0 : "auto",
        width: vertical ? "3px" : "auto",
        height: vertical ? "auto" : "3px",
        background: edge[s.stage] || "var(--line-hairline)"
      }
    }), React.createElement("span", {
      style: {
        fontFamily: "var(--font-mono)",
        fontSize: "var(--text-micro)",
        letterSpacing: ".12em",
        color: dark ? "var(--cli-slate-300)" : "var(--text-muted)"
      }
    }, String(i + 1).padStart(2, "0")), React.createElement("h3", {
      style: {
        fontSize: "var(--text-h4)",
        color: dark ? "var(--cli-paper-200)" : "var(--text-display)"
      }
    }, s.title), s.tag ? React.createElement(__ds_scope.Tag, {
      role: s.stage === "entry" ? "route" : s.stage === "run" ? "data" : dark ? "onDark" : "architecture",
      style: {
        justifySelf: "start"
      }
    }, s.tag) : null, React.createElement("p", {
      style: {
        fontSize: "var(--text-small)",
        color: dark ? "var(--text-on-dossier-muted)" : "var(--text-muted)"
      }
    }, s.text));
  }));
}
Object.assign(__ds_scope, { ProductLadder });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/technology/ProductLadder.jsx", error: String((e && e.message) || e) }); }

// components/technology/VisualizationShowcase.jsx
try { (() => {
/** Visualization plate + optional gallery tabs. Ready diagrams only - never a future image. */
function VisualizationShowcase({
  items = [],
  activeIndex = 0,
  onSelect,
  showTabs,
  frame = "strong",
  caption
}) {
  const it = items[activeIndex] || items[0];
  if (!it) return null;
  return React.createElement("div", null, showTabs && items.length > 1 ? React.createElement("div", {
    role: "tablist",
    style: {
      display: "flex",
      flexWrap: "wrap",
      borderBottom: "1px solid var(--line-hairline)",
      marginBottom: "var(--space-6)"
    }
  }, items.map((v, i) => React.createElement("button", {
    key: v.src,
    role: "tab",
    "aria-selected": i === activeIndex,
    type: "button",
    onClick: onSelect ? () => onSelect(i) : undefined,
    style: {
      appearance: "none",
      background: "transparent",
      border: 0,
      borderBottom: "2px solid " + (i === activeIndex ? "var(--accent-tech)" : "transparent"),
      padding: "var(--space-3) var(--space-5)",
      minHeight: "var(--touch-min)",
      cursor: "pointer",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: i === activeIndex ? "var(--cli-navy-800)" : "var(--text-muted)",
      transition: "var(--transition-control)"
    }
  }, v.tabLabel || v.index))) : null, React.createElement("figure", {
    style: {
      margin: 0,
      border: frame === "strong" ? "2px solid var(--line-strong)" : "1px solid var(--cli-paper-500)",
      background: "var(--surface-card)",
      boxShadow: frame === "raised" ? "var(--shadow-raised)" : "var(--shadow-card)"
    }
  }, React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-4)",
      padding: "var(--space-3) var(--space-4)",
      borderBottom: "1px solid var(--cli-paper-500)",
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      color: "var(--text-muted)"
    }
  }, React.createElement("span", null, it.title), it.meta ? React.createElement("span", null, it.meta) : null), React.createElement("img", {
    src: it.src,
    alt: it.alt,
    style: {
      width: "100%",
      display: "block",
      background: "var(--surface-schema)"
    },
    loading: "lazy",
    width: it.width || 3840,
    height: it.height || 2160
  }), React.createElement("figcaption", {
    style: {
      padding: "var(--space-4)",
      borderTop: "1px solid var(--cli-paper-500)",
      fontSize: "var(--text-small)",
      color: "var(--text-muted)",
      display: "flex",
      justifyContent: "space-between",
      gap: "var(--space-4)"
    }
  }, React.createElement("span", null, it.caption || caption), it.index ? React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      letterSpacing: ".1em",
      textTransform: "uppercase",
      whiteSpace: "nowrap"
    }
  }, it.index) : null)));
}
Object.assign(__ds_scope, { VisualizationShowcase });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/technology/VisualizationShowcase.jsx", error: String((e && e.message) || e) }); }

// ui_kits/technology-site-clm/TechnologySiteCLM.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/* CLM technology site — desktop screen. Composes the design-system components only. */
const {
  Header,
  Footer,
  StickySectionNav,
  TechnologyHero,
  TechnologyIntro,
  OpportunityBlock,
  SituationBlock,
  WhatItIsNot,
  ComparisonMatrix,
  ProductLadder,
  VisualizationShowcase,
  CaseCard,
  CaseFlow,
  MaterialCard,
  OnePageBlock,
  CTABlock,
  RequestDiagnosticsForm,
  Band,
  Button
} = window.CLevelInsightDesignSystem_27a32f;
function TechnologySiteCLM() {
  const d = window.CLM;
  const [active, setActive] = React.useState("hero");
  const [viz, setViz] = React.useState(0);
  const [layer, setLayer] = React.useState("o1");
  const [ladder, setLadder] = React.useState(0);
  const [state, setState] = React.useState("idle");
  const [errors, setErrors] = React.useState({});
  function submit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const next = {};
    if (!fd.get("name")) next.name = "Укажите имя";
    if (!fd.get("contact")) next.contact = "Укажите e-mail или телефон";
    if (!fd.get("consent")) next.consent = "Требуется согласие на обработку данных";
    setErrors(next);
    if (Object.keys(next).length) return;
    setState("sending");
    setTimeout(() => setState("sent"), 700);
  }
  return /*#__PURE__*/React.createElement("div", {
    id: "top"
  }, /*#__PURE__*/React.createElement(Header, {
    technology: d.technology,
    index: d.index,
    links: d.navLinks
  }), /*#__PURE__*/React.createElement(TechnologyHero, {
    eyebrow: d.hero.eyebrow,
    title: d.hero.title,
    formula: d.hero.formula,
    notes: d.hero.notes,
    nextHint: d.hero.nextHint,
    visualization: /*#__PURE__*/React.createElement(VisualizationShowcase, {
      items: [d.viz[0]]
    })
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      background: "var(--surface-page)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container-wide)",
      margin: "0 auto",
      padding: "0 var(--gutter-desktop)",
      display: "grid",
      gridTemplateColumns: "210px 1fr",
      gap: "var(--space-16)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      paddingTop: "var(--band-py-tight)"
    }
  }, /*#__PURE__*/React.createElement(StickySectionNav, {
    items: d.sections,
    activeId: active,
    onSelect: setActive
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "core",
    eyebrow: "\u042F\u0434\u0440\u043E \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438",
    title: "\u0427\u0442\u043E \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u0442\u0441\u044F \u0432 \u043F\u0435\u0440\u0432\u043E\u043C \u043A\u0440\u0443\u0433\u0435",
    aside: "\u0428\u0435\u0441\u0442\u044C \u0441\u043B\u043E\u0451\u0432",
    width: "wide",
    tight: true,
    style: {
      paddingLeft: 0,
      paddingRight: 0
    }
  }, /*#__PURE__*/React.createElement(TechnologyIntro, {
    statement: d.intro.statement,
    body: d.intro.body,
    aside: d.intro.aside,
    layers: d.intro.layers
  })), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "opportunity",
    eyebrow: "\u0427\u0442\u043E \u043E\u0442\u043A\u0440\u044B\u0432\u0430\u0435\u0442 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u044F",
    title: "\u0427\u0442\u043E \u0441\u0442\u0430\u043D\u043E\u0432\u0438\u0442\u0441\u044F \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C\u044B\u043C",
    width: "wide",
    tight: true,
    style: {
      paddingLeft: 0,
      paddingRight: 0
    }
  }, /*#__PURE__*/React.createElement(OpportunityBlock, {
    items: d.opportunities.slice(0, 4)
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-10)"
    }
  }, /*#__PURE__*/React.createElement(OpportunityBlock, {
    mode: "accordion",
    items: d.opportunities,
    openId: layer,
    onToggle: setLayer
  }))), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "situation",
    eyebrow: "\u041A\u043E\u0433\u0434\u0430 \u0443\u043C\u0435\u0441\u0442\u043D\u0430",
    title: "\u0423\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0447\u0435\u0441\u043A\u0438\u0435 \u0441\u0438\u0442\u0443\u0430\u0446\u0438\u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438",
    width: "wide",
    tight: true,
    style: {
      paddingLeft: 0,
      paddingRight: 0
    }
  }, /*#__PURE__*/React.createElement(SituationBlock, {
    situations: d.situations,
    notApplicable: d.notApplicable
  }))))), /*#__PURE__*/React.createElement(Band, {
    tone: "paperGrid",
    id: "isnot",
    eyebrow: "\u0427\u0442\u043E \u044D\u0442\u043E / \u0447\u0442\u043E \u044D\u0442\u043E \u043D\u0435",
    title: "\u041F\u0440\u0430\u0432\u0438\u043B\u044C\u043D\u0430\u044F \u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F \u0432\u043E\u0441\u043F\u0440\u0438\u044F\u0442\u0438\u044F",
    aside: "\u041C\u0430\u0442\u0440\u0438\u0446\u0430 \u0430\u043D\u0442\u0438-\u043A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u0439",
    width: "wide"
  }, /*#__PURE__*/React.createElement(WhatItIsNot, {
    formula: "\u041D\u0435 \u043A\u0430\u0434\u0440\u043E\u0432\u0430\u044F \u043E\u0446\u0435\u043D\u043A\u0430 \u0434\u0438\u0440\u0435\u043A\u0442\u043E\u0440\u043E\u0432, \u043D\u0435 \u043A\u043E\u0443\u0447\u0438\u043D\u0433 \u0438 \u043D\u0435 \u043D\u043E\u0432\u0430\u044F \u043E\u0440\u0433\u0441\u0442\u0440\u0443\u043A\u0442\u0443\u0440\u0430.",
    isNot: d.isNot,
    isThis: d.isThis
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "var(--space-16)"
    }
  }, /*#__PURE__*/React.createElement(ComparisonMatrix, {
    columns: ["Критерий", "Ручной маршрут", "Управляемый контур"],
    highlightColumn: 2,
    caption: "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435 \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438, \u0430 \u043D\u0435 \u043E\u0446\u0435\u043D\u043A\u0430 \u043A\u043E\u043C\u043F\u0430\u043D\u0438\u0438. \u041F\u0443\u0431\u043B\u0438\u0447\u043D\u044B\u0439 scoring, \u0440\u0430\u0434\u0430\u0440 \u0438 \u0442\u0435\u0441\u0442 \u0437\u0440\u0435\u043B\u043E\u0441\u0442\u0438 \u0432 \u0441\u0438\u0441\u0442\u0435\u043C\u0435 \u0437\u0430\u043F\u0440\u0435\u0449\u0435\u043D\u044B.",
    rows: [{
      label: "Скорость решения",
      cells: [{
        text: "Скорость одного человека",
        tone: "stop"
      }, {
        text: "Скорость мандата",
        tone: "go",
        strong: true
      }]
    }, {
      label: "Владелец данных",
      cells: [{
        text: "Не определён",
        tone: "stop"
      }, {
        text: "Закреплён в роли",
        tone: "go"
      }]
    }, {
      label: "Ритм",
      cells: ["Совещание как способ решить", "Повестка решений"]
    }, {
      label: "Отклонение",
      cells: [{
        text: "Обнаруживается поздно",
        tone: "stop"
      }, {
        text: "Имеет владельца и срок",
        tone: "go"
      }]
    }]
  }))), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "how",
    eyebrow: "\u041A\u0430\u043A \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \xB7 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\u0430\u044F \u043B\u0435\u0441\u0442\u043D\u0438\u0446\u0430",
    title: "\u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u2192 \u0421\u0435\u0441\u0441\u0438\u044F \u2192 \u0421\u043F\u0440\u0438\u043D\u0442 30-60-90 \u2192 \u0421\u043E\u043F\u0440\u043E\u0432\u043E\u0436\u0434\u0435\u043D\u0438\u0435",
    aside: "\u041C\u0430\u0440\u0448\u0440\u0443\u0442 \u0435\u0434\u0438\u043D \u0434\u043B\u044F 7 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0439",
    width: "wide"
  }, /*#__PURE__*/React.createElement(ProductLadder, {
    steps: d.ladder,
    activeIndex: ladder,
    onSelect: setLadder
  })), /*#__PURE__*/React.createElement(Band, {
    tone: "paperGrid",
    id: "viz",
    eyebrow: "\u0412\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u0438 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438",
    title: "\u0421\u0445\u0435\u043C\u0430 \u043E\u0431\u044A\u044F\u0441\u043D\u044F\u0435\u0442 \u0431\u044B\u0441\u0442\u0440\u0435\u0435 \u0442\u0435\u043A\u0441\u0442\u0430",
    aside: `${viz + 1} / ${d.viz.length}`,
    width: "wide"
  }, /*#__PURE__*/React.createElement(VisualizationShowcase, {
    items: d.viz,
    activeIndex: viz,
    onSelect: setViz,
    showTabs: true
  })), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "cases",
    eyebrow: "\u041A\u0435\u0439\u0441\u044B \xB7 \u0434\u043E\u043A\u0430\u0437\u0430\u0442\u0435\u043B\u044C\u0441\u0442\u0432\u043E \u043F\u0440\u0438\u043C\u0435\u043D\u0438\u043C\u043E\u0441\u0442\u0438",
    title: "\u0427\u0442\u043E \u0441\u0442\u0430\u043B\u043E \u0443\u043F\u0440\u0430\u0432\u043B\u044F\u0435\u043C\u044B\u043C",
    width: "wide"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit,minmax(380px,1fr))",
      gap: "var(--space-6)"
    }
  }, d.cases.map(c => /*#__PURE__*/React.createElement(CaseCard, _extends({
    key: c.sector
  }, c, {
    href: "#"
  }))))), /*#__PURE__*/React.createElement(Band, {
    tone: "dossierGrid",
    eyebrow: "\u041A\u0435\u0439\u0441 \xB7 \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0447\u0435\u0441\u043A\u0438\u0439 \u043F\u043E\u0442\u043E\u043A",
    title: "\u041E\u0434\u0438\u043D \u043A\u0435\u0439\u0441 \u043A\u0430\u043A \u043F\u043E\u0441\u043B\u0435\u0434\u043E\u0432\u0430\u0442\u0435\u043B\u044C\u043D\u043E\u0441\u0442\u044C \u0441\u043E\u0441\u0442\u043E\u044F\u043D\u0438\u0439",
    width: "wide",
    tight: true
  }, /*#__PURE__*/React.createElement(CaseFlow, {
    steps: d.caseFlow
  })), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "materials",
    eyebrow: "\u041C\u0430\u0442\u0435\u0440\u0438\u0430\u043B\u044B \u0438 \u0430\u0440\u0442\u0435\u0444\u0430\u043A\u0442\u044B",
    title: "One-page, \u043F\u0440\u0435\u0437\u0435\u043D\u0442\u0430\u0446\u0438\u044F, \u043F\u0430\u043A\u0435\u0442 \u0441\u0445\u0435\u043C",
    width: "wide"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-3)",
      marginBottom: "var(--space-12)"
    }
  }, d.materials.map(m => /*#__PURE__*/React.createElement(MaterialCard, _extends({
    key: m.title
  }, m, {
    href: "#"
  })))), /*#__PURE__*/React.createElement(OnePageBlock, {
    title: "One-page \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438",
    description: "\u041E\u0434\u043D\u0430 \u0441\u0442\u0440\u0430\u043D\u0438\u0446\u0430 \u043E \u0442\u043E\u043C, \u0447\u0442\u043E \u043D\u0430\u0441\u0442\u0440\u0430\u0438\u0432\u0430\u0435\u0442 CLM, \u0434\u043B\u044F \u043A\u043E\u0433\u043E \u0438 \u0441 \u0447\u0435\u0433\u043E \u043D\u0430\u0447\u0438\u043D\u0430\u0435\u0442\u0441\u044F \u0432\u0445\u043E\u0434.",
    bullets: ["Ядро и шесть слоёв первого круга", "Четыре продукта технологии", "Условия входа в Диагностику"],
    secondary: {
      label: "Посмотреть кейсы",
      href: "#cases"
    }
  })), /*#__PURE__*/React.createElement(CTABlock, {
    title: "\u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u043A\u0440\u0443\u0433\u0430",
    body: "\u041F\u0435\u0440\u0432\u0438\u0447\u043D\u044B\u0439 \u0434\u0438\u0430\u0433\u043D\u043E\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438, \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0447\u0435\u0441\u043A\u0438\u0439 \u0432\u0435\u0440\u0434\u0438\u043A\u0442 \u0438 \u043F\u0440\u0430\u0432\u043E \u043D\u0430 STOP.",
    secondaryCta: {
      label: "Получить one-page",
      href: "#materials"
    },
    terms: d.ctaTerms
  }), /*#__PURE__*/React.createElement(Band, {
    tone: "paper",
    id: "diagnostics",
    eyebrow: "\u0417\u0430\u044F\u0432\u043A\u0430",
    title: "\u041A\u043E\u0440\u043E\u0442\u043A\u0430\u044F \u0437\u0430\u044F\u0432\u043A\u0430 \u043D\u0430 \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0443",
    width: "wide"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "minmax(320px,620px) 1fr",
      gap: "var(--space-16)",
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement(RequestDiagnosticsForm, {
    note: "\u041E\u0442\u0432\u0435\u0442 \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0434\u0432\u0443\u0445 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u043D\u0435\u0439. \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u043D\u0435 \u043F\u0440\u043E\u0432\u043E\u0434\u0438\u0442\u0441\u044F \u043D\u0430 \u0441\u0430\u0439\u0442\u0435.",
    state: state,
    errors: errors,
    onSubmit: submit
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: "var(--space-5)",
      paddingLeft: "var(--space-5)",
      borderLeft: "2px solid var(--accent-tech)"
    }
  }, d.ctaTerms.map((t, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      display: "grid",
      gridTemplateColumns: "26px 1fr",
      gap: "var(--space-3)"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: "var(--text-micro)",
      color: "var(--accent-tech)"
    }
  }, String(i + 1).padStart(2, "0")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: "var(--text-small)",
      color: "var(--text-muted)"
    }
  }, t))), /*#__PURE__*/React.createElement(Button, {
    variant: "quiet",
    href: "#top",
    trailing: "\u2191"
  }, "\u0412\u0435\u0440\u043D\u0443\u0442\u044C\u0441\u044F \u043A \u044F\u0434\u0440\u0443 \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438")))), /*#__PURE__*/React.createElement(Footer, {
    technology: d.technology,
    columns: d.footerColumns,
    technologies: d.technologies,
    note: "\u041F\u0435\u0440\u0432\u044B\u0439 \u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0432\u0445\u043E\u0434 \u0432 \u043B\u044E\u0431\u0443\u044E \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u044E \u2014 \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430. \u041E\u0431\u0435\u0449\u0430\u043D\u0438\u044F \u0440\u0435\u0437\u0443\u043B\u044C\u0442\u0430\u0442\u0430 \u0434\u043E \u043D\u0435\u0451 \u043D\u0435\u0442."
  }));
}
Object.assign(window, {
  TechnologySiteCLM
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/technology-site-clm/TechnologySiteCLM.jsx", error: String((e && e.message) || e) }); }

// ui_kits/technology-site-clm/TechnologySiteCLMMobile.jsx
try { (() => {
/* CLM technology site — mobile screen (390px). Same components, mobile behaviour rules applied. */
const {
  Header,
  StickySectionNav,
  ProductLadder,
  MobileVisualizationPreview,
  WhatItIsNot,
  CaseCard,
  RequestDiagnosticsForm,
  CTABlock,
  Band,
  Button,
  Tag
} = window.CLevelInsightDesignSystem_27a32f;
function TechnologySiteCLMMobile() {
  const d = window.CLM;
  const [active, setActive] = React.useState("viz");
  const [open, setOpen] = React.useState(false);
  const [step, setStep] = React.useState(0);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      width: 390,
      margin: "0 auto",
      background: "var(--surface-page)",
      overflow: "hidden",
      border: "1px solid var(--line-hairline)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "14px 16px",
      borderBottom: "1px solid var(--line-hairline)",
      display: "grid",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 17,
      fontWeight: 700,
      color: "var(--text-display)"
    }
  }, d.technology), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 10,
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--accent-tech)"
    }
  }, "C-LEVEL INSIGHT \xB7 \u0422\u0415\u0425\u041D\u041E\u041B\u041E\u0413\u0418\u042F ", d.index)), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "20px 16px",
      background: "var(--surface-page)",
      backgroundImage: "var(--grid-paper)",
      backgroundSize: "var(--grid-repeat)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      paddingBottom: 8,
      borderBottom: "2px solid var(--accent-tech)",
      display: "inline-block"
    }
  }, "\u042F\u0434\u0440\u043E \u0442\u0435\u0445\u043D\u043E\u043B\u043E\u0433\u0438\u0438"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontSize: "var(--text-hero)",
      lineHeight: 1.06,
      margin: "16px 0 0"
    }
  }, d.hero.title), /*#__PURE__*/React.createElement("p", {
    style: {
      marginTop: 12,
      fontSize: 17,
      lineHeight: 1.55,
      color: "var(--cli-slate-600)"
    }
  }, d.hero.formula), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 8,
      marginTop: 20
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    href: "#diagnostics"
  }, "\u0417\u0430\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0443"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg",
    href: "#how",
    trailing: "\u2192"
  }, "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C, \u043A\u0430\u043A \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442"))), /*#__PURE__*/React.createElement(StickySectionNav, {
    items: d.sections.slice(0, 6),
    activeId: active,
    onSelect: setActive,
    orientation: "horizontal"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "24px 16px",
      display: "grid",
      gap: 32
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 12
    }
  }, "\u0412\u0438\u0437\u0443\u0430\u043B\u0438\u0437\u0430\u0446\u0438\u044F \xB7 mobile preview"), /*#__PURE__*/React.createElement(MobileVisualizationPreview, {
    item: {
      src: d.viz[0].src,
      alt: d.viz[0].alt,
      title: d.viz[0].title,
      caption: "Полная схема открывается на весь экран с прокруткой."
    },
    open: open,
    onOpen: () => setOpen(true),
    onClose: () => setOpen(false)
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 12
    }
  }, "\u041A\u0430\u043A \u0440\u0430\u0431\u043E\u0442\u0430\u0435\u0442 \xB7 \u0432\u0435\u0440\u0442\u0438\u043A\u0430\u043B\u044C\u043D\u0430\u044F \u043B\u0435\u0441\u0442\u043D\u0438\u0446\u0430"), /*#__PURE__*/React.createElement(ProductLadder, {
    steps: d.ladder,
    orientation: "vertical",
    activeIndex: step,
    onSelect: setStep
  })), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 12
    }
  }, "\u042D\u0442\u043E \u043D\u0435 \xB7 \u0441\u0442\u0435\u043A \u0432\u043C\u0435\u0441\u0442\u043E \u0442\u0430\u0431\u043B\u0438\u0446\u044B"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gap: 10
    }
  }, d.isNot.slice(0, 3).map((n, i) => /*#__PURE__*/React.createElement("div", {
    key: n.title,
    style: {
      border: "1px solid var(--cli-paper-500)",
      background: "var(--surface-card)",
      padding: 14,
      display: "grid",
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    role: "stop",
    style: {
      justifySelf: "start"
    }
  }, n.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15,
      color: "var(--cli-red-700)"
    }
  }, n.text), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--cli-paper-400)",
      paddingTop: 8,
      display: "grid",
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Tag, {
    role: "data",
    style: {
      justifySelf: "start"
    }
  }, d.isThis[i].title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 15
    }
  }, d.isThis[i].text)))))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-label)",
      textTransform: "uppercase",
      color: "var(--text-muted)",
      marginBottom: 12
    }
  }, "\u041A\u0435\u0439\u0441"), /*#__PURE__*/React.createElement(CaseCard, d.cases[0]))), /*#__PURE__*/React.createElement("div", {
    id: "diagnostics",
    style: {
      padding: "24px 16px",
      background: "var(--surface-dossier-deep)",
      backgroundImage: "var(--grid-dossier)",
      backgroundSize: "var(--grid-repeat)",
      display: "grid",
      gap: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-mono)",
      fontSize: 11,
      letterSpacing: "var(--tracking-eyebrow)",
      textTransform: "uppercase",
      color: "var(--accent-tech)"
    }
  }, "\u041F\u0435\u0440\u0432\u044B\u0439 \u043F\u043B\u0430\u0442\u043D\u044B\u0439 \u0432\u0445\u043E\u0434"), /*#__PURE__*/React.createElement("h2", {
    style: {
      color: "var(--cli-paper-200)",
      fontSize: 30,
      lineHeight: 1.1
    }
  }, "\u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0430 \u043F\u0435\u0440\u0432\u043E\u0433\u043E \u043A\u0440\u0443\u0433\u0430"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 17,
      color: "var(--text-on-dossier-muted)"
    }
  }, "\u041F\u0435\u0440\u0432\u0438\u0447\u043D\u044B\u0439 \u0434\u0438\u0430\u0433\u043D\u043E\u0437 \u043A\u043E\u043D\u0441\u0442\u0440\u0443\u043A\u0446\u0438\u0438, \u0443\u043F\u0440\u0430\u0432\u043B\u0435\u043D\u0447\u0435\u0441\u043A\u0438\u0439 \u0432\u0435\u0440\u0434\u0438\u043A\u0442 \u0438 \u043F\u0440\u0430\u0432\u043E \u043D\u0430 STOP."), /*#__PURE__*/React.createElement(Button, {
    variant: "onDark",
    size: "lg"
  }, "\u0417\u0430\u043F\u0440\u043E\u0441\u0438\u0442\u044C \u0414\u0438\u0430\u0433\u043D\u043E\u0441\u0442\u0438\u043A\u0443")), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "24px 16px"
    }
  }, /*#__PURE__*/React.createElement(RequestDiagnosticsForm, {
    title: "\u0417\u0430\u044F\u0432\u043A\u0430",
    note: "\u041E\u0442\u0432\u0435\u0442 \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0434\u0432\u0443\u0445 \u0440\u0430\u0431\u043E\u0447\u0438\u0445 \u0434\u043D\u0435\u0439."
  })));
}
Object.assign(window, {
  TechnologySiteCLMMobile
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/technology-site-clm/TechnologySiteCLMMobile.jsx", error: String((e && e.message) || e) }); }

// ui_kits/technology-site-clm/data.js
try { (() => {
// Content for the CLM technology-site UI kit. Source: Управление Директорами / CLM
// client-meaning model + Матрица_Анти_Категорий v1.0 + the 5 visualization masters.
window.CLM = {
  technology: "Управление Директорами / CLM",
  index: "04",
  navLinks: [{
    label: "Возможность",
    href: "#opportunity"
  }, {
    label: "Как работает",
    href: "#how"
  }, {
    label: "Визуализации",
    href: "#viz"
  }, {
    label: "Кейсы",
    href: "#cases"
  }, {
    label: "Материалы",
    href: "#materials"
  }],
  sections: [{
    id: "hero",
    label: "Ядро"
  }, {
    id: "opportunity",
    label: "Возможность"
  }, {
    id: "situation",
    label: "Когда уместна"
  }, {
    id: "isnot",
    label: "Это не"
  }, {
    id: "how",
    label: "Как работает"
  }, {
    id: "viz",
    label: "Визуализации"
  }, {
    id: "cases",
    label: "Кейсы"
  }, {
    id: "materials",
    label: "Материалы"
  }],
  hero: {
    eyebrow: "Клиентский слой · Ядро технологии",
    title: "Первый круг как система управления",
    formula: "Роли, мандаты, решения, данные, ритмы и ответственность собираются вокруг результата, а не вокруг должностей.",
    notes: ["Технология настройки C-level-ядра, а не оценка директоров.", "Первый платный вход — Диагностика с правом на STOP.", "Схема открыта на первом экране: она объясняет быстрее текста."],
    nextHint: "Далее · что открывает технология"
  },
  intro: {
    statement: "Сначала система ролей и мандатов, потом человек в роли.",
    body: ["CLM работает не с личностями директоров и не со схемой подчинённости. Технология настраивает первый управленческий круг: какие функции должны быть видимы, кто имеет право решать, какие решения проходят через круг, на каких данных, в каком ритме и кто отвечает за отклонение.", "Результат — управляемый первый круг вместо набора сильных должностей."],
    aside: "Если решения ускоряются только присутствием CEO, круг ещё не собран как система.",
    layers: [{
      title: "Роли",
      text: "Какие управленческие функции должны быть видимы"
    }, {
      title: "Мандаты",
      text: "Кто имеет право и обязанность принимать решения"
    }, {
      title: "Решения",
      text: "Какие решения проходят через первый круг"
    }, {
      title: "Данные",
      text: "Какие данные нужны для решения и кто отвечает за их качество"
    }, {
      title: "Ритмы",
      text: "Как первый круг синхронизируется без лишних совещаний"
    }, {
      title: "Ответственность",
      text: "Кто отвечает за результат, отклонение и корректировку"
    }]
  },
  opportunities: [{
    id: "o1",
    title: "Скорость решения",
    text: "Межфункциональное решение не ждёт CEO в роли ручного маршрутизатора."
  }, {
    id: "o2",
    title: "Владельцы данных",
    text: "У каждого управленческого числа есть роль, отвечающая за его качество."
  }, {
    id: "o3",
    title: "Ритм без совещаний",
    text: "Круг синхронизируется по повестке решений, а не по календарю встреч."
  }, {
    id: "o4",
    title: "Видимая ответственность",
    text: "Отклонение имеет владельца и срок корректировки."
  }],
  situations: ["Сильные директора есть, а управляемого первого круга нет.", "Любое межфункциональное решение доходит до CEO.", "Управленческие числа есть, но у них нет владельца.", "Совещания стали способом принимать решения.", "Рост компании обогнал конструкцию первого круга."],
  notApplicable: ["Первый круг ещё не сформирован как состав.", "Собственник не готов передать мандаты.", "Задача сводится к замене конкретного директора."],
  isNot: [{
    title: "Не HR-оценка",
    text: "Не кадровая оценка директоров и не аттестация первого круга."
  }, {
    title: "Не коучинг",
    text: "Не персональная работа с личностью руководителя."
  }, {
    title: "Не новая оргструктура",
    text: "Не схема подчинённости и не список должностей."
  }, {
    title: "Не board portal",
    text: "Не система совещаний и не портал документов."
  }],
  isThis: [{
    title: "Роли и мандаты",
    text: "Какие управленческие функции видимы и кто имеет право решать."
  }, {
    title: "Решения и данные",
    text: "Какие решения проходят через круг и на каких данных."
  }, {
    title: "Ритмы и ответственность",
    text: "Как круг синхронизируется и кто отвечает за отклонение."
  }, {
    title: "Управляемый первый круг",
    text: "Конструкция вместо набора сильных должностей."
  }],
  ladder: [{
    title: "Диагностика",
    stage: "entry",
    tag: "Первый платный вход",
    text: "Первичный диагноз первого круга. Управленческий вердикт и право на продолжение или STOP."
  }, {
    title: "Сессия",
    stage: "build",
    tag: "Сборка решения",
    text: "Командная сборка решения и плана внедрения по ролям, мандатам и данным."
  }, {
    title: "Спринт 30-60-90",
    stage: "build",
    tag: "Оргпроект",
    text: "Внедрение как управляемый проект с владельцами и контрольными точками."
  }, {
    title: "Сопровождение",
    stage: "run",
    tag: "По запросу",
    text: "Поддержка обновлённой конструкции первого круга."
  }],
  viz: [{
    src: "../../assets/visualizations/clm-01-c-level-core.png",
    alt: "Схема C-level-ядра: роли, мандаты, решения, данные, ритмы и ответственность вокруг ядра",
    title: "Визуализация 01 · C-level-ядро",
    meta: "Role map · сложность средняя",
    index: "01 / 09",
    tabLabel: "01 · Ядро",
    caption: "Ядро и шесть слоёв первого круга. Маршрут решения идёт по часовой стрелке."
  }, {
    src: "../../assets/visualizations/clm-02-ceo-manual-router.png",
    alt: "Схема: CEO как ручной маршрутизатор решений",
    title: "Визуализация 02 · CEO как ручной маршрутизатор",
    meta: "Разрыв · сложность средняя",
    index: "02 / 09",
    tabLabel: "02 · Маршрутизатор",
    caption: "Когда CEO становится ручным маршрутизатором, скорость круга падает до скорости одного человека."
  }, {
    src: "../../assets/visualizations/clm-03-model-23-15-7.png",
    alt: "Схема модели 23-15-7",
    title: "Визуализация 03 · Модель 23-15-7",
    meta: "Структурные числа технологии",
    index: "03 / 09",
    tabLabel: "03 · Модель 23-15-7",
    caption: "Структурные числа технологии. Это не метрика зрелости и не оценка компании."
  }, {
    src: "../../assets/visualizations/clm-06-client-path-four-products.png",
    alt: "Схема клиентского пути: Диагностика, Сессия, Спринт 30-60-90, Сопровождение",
    title: "Визуализация 06 · Клиентский путь",
    meta: "Четыре продукта",
    index: "06 / 09",
    tabLabel: "06 · Клиентский путь",
    caption: "Четыре продукта технологии и точки управленческого решения между ними."
  }, {
    src: "../../assets/visualizations/clm-09-anti-positioning.png",
    alt: "Схема антипозиционирования CLM",
    title: "Визуализация 09 · Антипозиционирование",
    meta: "Это не · правильная категория",
    index: "09 / 09",
    tabLabel: "09 · Антипозиционирование",
    caption: "Ложные категории и правильная рамка восприятия технологии."
  }],
  cases: [{
    sector: "Производство",
    scale: "6 директоров · группа компаний",
    situation: "Выручка растёт третий год, скорость решений падает.",
    unmanageable: "Каждое межфункциональное решение доходило до CEO. Владельца данных по марже не существовало.",
    technology: "CLM: пересборка первого круга через роли, мандаты и перечень решений круга.",
    firstStep: "Диагностика: карта ролей и точек ручной маршрутизации. Вердикт — продолжение.",
    result: "Межфункциональные решения закреплены за мандатами. CEO вышел из маршрута."
  }, {
    sector: "Ритейл · омниканальность",
    scale: "8 директоров",
    situation: "Первый круг собран из сильных руководителей направлений.",
    unmanageable: "Решения по ассортименту и каналу принимались параллельно и противоречили друг другу.",
    technology: "CLM: перечень решений круга и ритм синхронизации по повестке решений.",
    firstStep: "Диагностика: какие решения обязаны проходить через круг.",
    result: "Конфликтующие решения сведены в одну повестку с владельцем."
  }],
  caseFlow: [{
    label: "Ситуация",
    text: "Группа компаний, 6 директоров, три года роста."
  }, {
    label: "Было неуправляемым",
    text: "Владельца данных по марже не существовало; решение ждало CEO.",
    state: "gap"
  }, {
    label: "Технология",
    text: "CLM: роли, мандаты и перечень решений первого круга."
  }, {
    label: "Первый шаг",
    text: "Диагностика: карта ролей и точек ручной маршрутизации."
  }, {
    label: "Стало управляемым",
    text: "Мандаты закреплены, владелец данных назван, круг синхронизируется по повестке.",
    state: "go"
  }],
  materials: [{
    kind: "ONE-PAGE",
    title: "CLM: первый круг за одну страницу",
    description: "Смысл технологии, четыре продукта и вход в Диагностику.",
    meta: "1 страница · PDF"
  }, {
    kind: "PPTX",
    title: "Презентация технологии",
    description: "Ядро, слои, продуктовая лестница и примеры ситуаций.",
    meta: "18 слайдов"
  }, {
    kind: "СХЕМЫ",
    title: "Пакет визуализаций CLM",
    description: "Схемы технологии в PNG и editable source для правок.",
    meta: "9 файлов"
  }],
  ctaTerms: ["Диагностика — платный вход, а не бесплатный пресейл.", "Результат не обещается до Диагностики.", "Диагностика не проводится на сайте: на сайте только заявка."],
  footerColumns: [{
    title: "Технология",
    links: [{
      label: "Как работает",
      href: "#how"
    }, {
      label: "Визуализации",
      href: "#viz"
    }, {
      label: "Кейсы",
      href: "#cases"
    }]
  }, {
    title: "Платформа",
    links: [{
      label: "C-Level Insight",
      href: "#"
    }, {
      label: "Связки технологий",
      href: "#"
    }, {
      label: "Кейсовая библиотека",
      href: "#"
    }]
  }, {
    title: "Материалы",
    links: [{
      label: "One-page",
      href: "#materials"
    }, {
      label: "Презентация",
      href: "#materials"
    }, {
      label: "Автор",
      href: "#"
    }]
  }],
  technologies: [{
    index: "01",
    name: "проSTRAнство",
    href: "#"
  }, {
    index: "02",
    name: "AI переход",
    href: "#"
  }, {
    index: "03",
    name: "Управленческая Точность",
    href: "#"
  }, {
    index: "04",
    name: "Управление Директорами / CLM",
    href: "#",
    active: true
  }, {
    index: "05",
    name: "Архитектура Переговоров",
    href: "#"
  }, {
    index: "06",
    name: "Контур Маржи",
    href: "#"
  }, {
    index: "07",
    name: "Повторяемый Спрос",
    href: "#"
  }]
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/technology-site-clm/data.js", error: String((e && e.message) || e) }); }

__ds_ns.CTABlock = __ds_scope.CTABlock;

__ds_ns.RequestDiagnosticsForm = __ds_scope.RequestDiagnosticsForm;

__ds_ns.Band = __ds_scope.Band;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Tag = __ds_scope.Tag;

__ds_ns.CaseCard = __ds_scope.CaseCard;

__ds_ns.CaseFlow = __ds_scope.CaseFlow;

__ds_ns.MaterialCard = __ds_scope.MaterialCard;

__ds_ns.OnePageBlock = __ds_scope.OnePageBlock;

__ds_ns.Footer = __ds_scope.Footer;

__ds_ns.Header = __ds_scope.Header;

__ds_ns.StickySectionNav = __ds_scope.StickySectionNav;

__ds_ns.ComparisonMatrix = __ds_scope.ComparisonMatrix;

__ds_ns.WhatItIsNot = __ds_scope.WhatItIsNot;

__ds_ns.OpportunityBlock = __ds_scope.OpportunityBlock;

__ds_ns.SituationBlock = __ds_scope.SituationBlock;

__ds_ns.TechnologyHero = __ds_scope.TechnologyHero;

__ds_ns.TechnologyIntro = __ds_scope.TechnologyIntro;

__ds_ns.MobileVisualizationPreview = __ds_scope.MobileVisualizationPreview;

__ds_ns.ProductLadder = __ds_scope.ProductLadder;

__ds_ns.VisualizationShowcase = __ds_scope.VisualizationShowcase;

})();
