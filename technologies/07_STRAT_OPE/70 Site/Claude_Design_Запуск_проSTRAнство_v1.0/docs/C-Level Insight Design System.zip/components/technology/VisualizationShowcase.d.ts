import type * as React from "react";
export interface VisualizationItem {
  src: string;
  /** Required: schemas are meaningful content, so alt text is mandatory. */
  alt: string;
  /** Mono head, e.g. "Визуализация 01 · C-level-ядро". */
  title: string;
  /** Right side of the mono head, e.g. "Role map · сложность средняя". */
  meta?: string;
  caption?: string;
  /** Mono index shown in the caption, e.g. "01 / 09". */
  index?: string;
  tabLabel?: string;
  width?: number;
  height?: number;
}
/**
 * Plate for the ready visualizations. A caption is always required.
 * @startingPoint section="Technology site" subtitle="Visualization plate with gallery tabs" viewport="1280x760"
 */
export interface VisualizationShowcaseProps {
  items?: VisualizationItem[];
  activeIndex?: number;
  onSelect?: (index: number) => void;
  showTabs?: boolean;
  /** strong = 2px navy frame (hero object); raised = 1px + raised shadow (lifted out of a dark context). */
  frame?: "strong" | "raised";
  caption?: string;
}
export declare function VisualizationShowcase(props: VisualizationShowcaseProps): JSX.Element;
