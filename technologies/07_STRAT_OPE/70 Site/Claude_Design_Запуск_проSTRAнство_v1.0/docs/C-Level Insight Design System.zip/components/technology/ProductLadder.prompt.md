The unchanging four-product route of every technology. Diagnostics is a paid entry with the right to STOP - never framed as a free presale.

```jsx
<ProductLadder steps={[
  {title:"Диагностика",stage:"entry",tag:"Первый платный вход",text:"Первичный диагноз. Право на продолжение или STOP."},
  {title:"Сессия",stage:"build",text:"Командная сборка решения и плана внедрения."},
  {title:"Спринт 30-60-90",stage:"build",text:"Внедрение как оргпроект."},
  {title:"Сопровождение",stage:"run",tag:"По запросу",text:"Поддержка обновлённой конструкции."}]} />
```

Always four steps, always in this order, on all 7 sites. `orientation="vertical"` below 768px.
