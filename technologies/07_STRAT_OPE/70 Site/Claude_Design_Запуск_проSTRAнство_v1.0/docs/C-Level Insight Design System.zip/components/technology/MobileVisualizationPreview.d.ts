import type * as React from "react";
export interface MobileVizItem { src: string; alt: string; title: string; caption?: string }
export interface MobileVisualizationPreviewProps {
  item?: MobileVizItem;
  open?: boolean;
  onOpen?: () => void;
  onClose?: () => void;
  openLabel?: string;
  closeLabel?: string;
}
export declare function MobileVisualizationPreview(props: MobileVisualizationPreviewProps): JSX.Element;
