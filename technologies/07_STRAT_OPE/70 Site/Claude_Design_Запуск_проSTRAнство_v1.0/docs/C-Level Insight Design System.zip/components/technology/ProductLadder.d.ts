import type * as React from "react";
export interface LadderStep {
  title: string;
  text: string;
  /** entry = Диагностика (copper); build = Сессия / Спринт (navy); run = Сопровождение (teal). */
  stage?: "entry" | "build" | "run";
  tag?: string;
}
/**
 * The four-product route. Never altered per technology.
 * @startingPoint section="Technology site" subtitle="Product ladder: Диагностика → Сессия → Спринт → Сопровождение" viewport="1280x340"
 */
export interface ProductLadderProps {
  steps?: LadderStep[];
  /** horizontal stepper on desktop; vertical is the mobile / dossier-band form. */
  orientation?: "horizontal" | "vertical";
  activeIndex?: number;
  onSelect?: (index: number) => void;
  tone?: "paper" | "dossier";
}
export declare function ProductLadder(props: ProductLadderProps): JSX.Element;
