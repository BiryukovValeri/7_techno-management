import React from "react";

/** Mobile form of a schema: fixed 16:9 preview that opens full-screen instead of shrinking text to nothing. */
export function MobileVisualizationPreview({item,open,onOpen,onClose,openLabel="Открыть схему",closeLabel="Закрыть"}){
  if(!item) return null;
  return React.createElement("div",null,
    React.createElement("figure",{style:{margin:0,border:"1px solid var(--cli-paper-500)",background:"var(--surface-card)"}},
      React.createElement("div",{style:{padding:"var(--space-3) var(--space-4)",borderBottom:"1px solid var(--cli-paper-500)",fontFamily:"var(--font-mono)",fontSize:"11px",letterSpacing:".1em",textTransform:"uppercase",color:"var(--text-muted)"}},item.title),
      React.createElement("div",{style:{aspectRatio:"var(--viz-ratio)",overflow:"hidden",background:"var(--surface-schema)"}},
        React.createElement("img",{src:item.src,alt:item.alt,style:{width:"100%",display:"block"},loading:"lazy"})),
      React.createElement("figcaption",{style:{padding:"var(--space-4)",borderTop:"1px solid var(--cli-paper-500)",display:"grid",gap:"var(--space-4)"}},
        React.createElement("p",{style:{fontSize:"var(--text-small)",color:"var(--text-muted)"}},item.caption),
        React.createElement("button",{type:"button",onClick:onOpen,style:{appearance:"none",minHeight:"var(--touch-min)",padding:"0 var(--space-6)",background:"var(--cli-navy-800)",color:"var(--cli-paper-200)",border:0,borderRadius:"var(--radius-xs)",fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",fontWeight:"var(--weight-semibold)",cursor:"pointer",justifySelf:"start"}},openLabel+" ↗"))),
    open?React.createElement("div",{role:"dialog","aria-modal":"true",style:{position:"fixed",inset:0,zIndex:50,background:"var(--surface-dossier-deep)",display:"grid",gridTemplateRows:"auto 1fr"}},
      React.createElement("div",{style:{display:"flex",justifyContent:"space-between",alignItems:"center",gap:"var(--space-4)",padding:"var(--space-4)",borderBottom:"1px solid var(--line-on-dossier)"}},
        React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"11px",letterSpacing:".1em",textTransform:"uppercase",color:"var(--cli-paper-200)"}},item.title),
        React.createElement("button",{type:"button",onClick:onClose,style:{appearance:"none",minHeight:"var(--touch-min)",minWidth:"var(--touch-min)",background:"transparent",border:"1px solid var(--line-on-dossier)",color:"var(--cli-paper-200)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",cursor:"pointer",padding:"0 var(--space-4)"}},closeLabel+" ×")),
      React.createElement("div",{style:{overflow:"auto",padding:"var(--space-4)",background:"var(--surface-schema)"}},
        React.createElement("img",{src:item.src,alt:item.alt,style:{width:"260%",maxWidth:"none",display:"block"}}))):null);
}
