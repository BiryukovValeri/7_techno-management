import React from "react";

/** Visualization plate + optional gallery tabs. Ready diagrams only - never a future image. */
export function VisualizationShowcase({items=[],activeIndex=0,onSelect,showTabs,frame="strong",caption}){
  const it=items[activeIndex]||items[0];
  if(!it) return null;
  return React.createElement("div",null,
    showTabs&&items.length>1?React.createElement("div",{role:"tablist",style:{display:"flex",flexWrap:"wrap",borderBottom:"1px solid var(--line-hairline)",marginBottom:"var(--space-6)"}},
      items.map((v,i)=>React.createElement("button",{key:v.src,role:"tab","aria-selected":i===activeIndex,type:"button",onClick:onSelect?()=>onSelect(i):undefined,
        style:{appearance:"none",background:"transparent",border:0,borderBottom:"2px solid "+(i===activeIndex?"var(--accent-tech)":"transparent"),padding:"var(--space-3) var(--space-5)",minHeight:"var(--touch-min)",cursor:"pointer",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:i===activeIndex?"var(--cli-navy-800)":"var(--text-muted)",transition:"var(--transition-control)"}},v.tabLabel||v.index))):null,
    React.createElement("figure",{style:{margin:0,border:frame==="strong"?"2px solid var(--line-strong)":"1px solid var(--cli-paper-500)",background:"var(--surface-card)",boxShadow:frame==="raised"?"var(--shadow-raised)":"var(--shadow-card)"}},
      React.createElement("div",{style:{display:"flex",justifyContent:"space-between",gap:"var(--space-4)",padding:"var(--space-3) var(--space-4)",borderBottom:"1px solid var(--cli-paper-500)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--text-muted)"}},
        React.createElement("span",null,it.title),
        it.meta?React.createElement("span",null,it.meta):null),
      React.createElement("img",{src:it.src,alt:it.alt,style:{width:"100%",display:"block",background:"var(--surface-schema)"},loading:"lazy",width:it.width||3840,height:it.height||2160}),
      React.createElement("figcaption",{style:{padding:"var(--space-4)",borderTop:"1px solid var(--cli-paper-500)",fontSize:"var(--text-small)",color:"var(--text-muted)",display:"flex",justifyContent:"space-between",gap:"var(--space-4)"}},
        React.createElement("span",null,it.caption||caption),
        it.index?React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",whiteSpace:"nowrap"}},it.index):null)));
}
