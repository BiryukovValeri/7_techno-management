Below 768px a 3840px schema cannot be shrunk to fit - it becomes a fixed 16:9 preview plus a full-screen pannable view.

```jsx
<MobileVisualizationPreview item={viz01} open={open} onOpen={()=>setOpen(true)} onClose={()=>setOpen(false)} />
```

Mandatory wherever VisualizationShowcase appears. Guarantees no horizontal page scroll and no unreadable schema text.
