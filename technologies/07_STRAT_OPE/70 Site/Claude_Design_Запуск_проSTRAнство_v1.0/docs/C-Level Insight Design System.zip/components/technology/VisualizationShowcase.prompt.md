Houses the ready diagrams from the technology's visualization library. 3-5 on the main page, the rest under Materials.

```jsx
<VisualizationShowcase showTabs items={[
  {src:"assets/visualizations/clm-01-c-level-core.png",title:"Визуализация 01 · C-level-ядро",
   meta:"Role map · сложность средняя", index:"01 / 09", tabLabel:"01 · Ядро",
   alt:"Схема C-level-ядра", caption:"Схема объясняет быстрее текста."}]} />
```

Never put a schema on a dark band or under a scrim, and never mix an `<image-slot>` into this component.
