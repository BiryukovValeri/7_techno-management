import React from "react";
import { Tag } from "../core/Tag.jsx";
const edge={entry:"var(--role-route)",build:"var(--role-architecture)",run:"var(--role-data)"};
/** Диагностика → Сессия → Спринт 30-60-90 → Сопровождение. Identical on all 7 sites. */
export function ProductLadder({steps=[],orientation="horizontal",activeIndex,onSelect,tone="paper"}){
  const dark=tone==="dossier";
  const vertical=orientation==="vertical";
  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:vertical?"1fr":"repeat("+(steps.length||4)+",1fr)",gap:vertical?"1px":0,background:dark?"var(--line-on-dossier)":"transparent",border:dark?"none":"1px solid var(--line-hairline)"}},
    steps.map((s,i)=>{const active=activeIndex===i;
      return React.createElement(onSelect?"button":"div",{key:s.title,type:onSelect?"button":undefined,onClick:onSelect?()=>onSelect(i):undefined,
        style:{position:"relative",textAlign:"left",appearance:"none",cursor:onSelect?"pointer":"default",font:"inherit",
          background:dark?(active?"var(--cli-navy-700)":"var(--cli-navy-800)"):(active?"var(--cli-paper-200)":"var(--surface-card)"),
          color:dark?"var(--text-on-dossier)":"var(--text-body)",
          border:0,borderRight:!vertical&&i<steps.length-1?(dark?"1px solid var(--line-on-dossier)":"1px solid var(--line-hairline)"):"none",
          padding:"var(--space-6)",minHeight:"var(--touch-min)",display:"grid",gap:"var(--space-3)",alignContent:"start",transition:"var(--transition-control)"}},
        React.createElement("span",{style:{position:"absolute",top:0,left:0,right:vertical?"auto":0,bottom:vertical?0:"auto",width:vertical?"3px":"auto",height:vertical?"auto":"3px",background:edge[s.stage]||"var(--line-hairline)"}}),
        React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".12em",color:dark?"var(--cli-slate-300)":"var(--text-muted)"}},String(i+1).padStart(2,"0")),
        React.createElement("h3",{style:{fontSize:"var(--text-h4)",color:dark?"var(--cli-paper-200)":"var(--text-display)"}},s.title),
        s.tag?React.createElement(Tag,{role:s.stage==="entry"?"route":s.stage==="run"?"data":dark?"onDark":"architecture",style:{justifySelf:"start"}},s.tag):null,
        React.createElement("p",{style:{fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)"}},s.text));}));
}
