Ruled dossier table for comparing options, technologies or before/after states.

```jsx
<ComparisonMatrix columns={["Критерий","Ручной маршрут","Управляемый контур"]} highlightColumn={2}
  rows={[{label:"Скорость решения",cells:[{text:"Скорость одного человека",tone:"stop"},{text:"Скорость мандата",tone:"go"}]}]} />
```

Never a scoring table, never a maturity test, never percentages without an approved source. On mobile it degrades to stacked blocks - see MobileVisualizationPreview for the same principle applied to schemas.
