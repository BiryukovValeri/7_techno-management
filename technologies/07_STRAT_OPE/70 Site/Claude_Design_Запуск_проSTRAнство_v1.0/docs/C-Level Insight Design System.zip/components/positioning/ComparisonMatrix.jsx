import React from "react";

/** Comparison matrix: technologies, options or before/after states as a ruled dossier table. */
export function ComparisonMatrix({columns=[],rows=[],highlightColumn,caption}){
  const cellPad="11px var(--space-4)";
  return React.createElement("div",null,
    React.createElement("table",{style:{width:"100%",borderCollapse:"collapse",background:"var(--surface-card)",border:"2px solid var(--line-strong)"}},
      React.createElement("thead",null,React.createElement("tr",null,
        React.createElement("th",{style:{textAlign:"left",padding:cellPad,background:"var(--surface-dossier)",color:"#e8b39a",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",fontWeight:"var(--weight-medium)",width:"26%"}},columns[0]||""),
        columns.slice(1).map((c,i)=>React.createElement("th",{key:c,style:{textAlign:"left",padding:cellPad,background:"var(--surface-dossier)",color:"var(--cli-paper-200)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",fontWeight:"var(--weight-medium)",borderBottom:highlightColumn===i+1?"3px solid var(--accent-tech)":"none"}},c)))),
      React.createElement("tbody",null,
        rows.map((r,ri)=>React.createElement("tr",{key:ri},
          React.createElement("th",{style:{textAlign:"left",padding:cellPad,borderBottom:ri<rows.length-1?"1px solid var(--cli-paper-400)":"none",fontSize:"var(--text-small)",fontWeight:"var(--weight-medium)",verticalAlign:"top"}},r.label),
          r.cells.map((c,ci)=>React.createElement("td",{key:ci,style:{padding:cellPad,borderBottom:ri<rows.length-1?"1px solid var(--cli-paper-400)":"none",fontSize:"var(--text-small)",verticalAlign:"top",color:c&&c.tone==="stop"?"var(--cli-red-700)":c&&c.tone==="go"?"var(--cli-teal-700)":"var(--text-body)",background:highlightColumn===ci+1?"var(--cli-paper-200)":"transparent",fontWeight:c&&c.strong?"var(--weight-semibold)":"var(--weight-regular)"}},c&&typeof c==="object"?c.text:c)))))),
    caption?React.createElement("p",{style:{marginTop:"var(--space-4)",fontSize:"var(--text-small)",color:"var(--text-muted)",maxWidth:"var(--measure-body)"}},caption):null);
}
