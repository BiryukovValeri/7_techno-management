import React from "react";

/** "Что это / что это не": the anti-category block. Removes a false category without arguing with the market. */
export function WhatItIsNot({isNot=[],isThis=[],formula,tone="paper"}){
  const dark=tone==="dossier";
  const rows=Math.max(isNot.length,isThis.length);
  const cell={padding:"var(--space-5) var(--space-6)"};
  const line=dark?"1px solid var(--line-on-dossier)":"1px solid var(--cli-paper-500)";
  return React.createElement("div",null,
    formula?React.createElement("p",{style:{fontFamily:"var(--font-display)",fontSize:"var(--text-h3)",lineHeight:"var(--leading-title)",maxWidth:"34ch",marginBottom:"var(--space-8)",color:dark?"var(--cli-paper-200)":"var(--text-display)"}},formula):null,
    React.createElement("div",{style:{border:dark?"1px solid var(--line-on-dossier)":"2px solid var(--line-strong)",background:dark?"var(--surface-dossier-raised)":"var(--surface-card)"}},
      React.createElement("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr"}},
        React.createElement("div",{style:{...cell,paddingTop:"var(--space-3)",paddingBottom:"var(--space-3)",background:dark?"transparent":"var(--surface-dossier)",color:"#e8b39a",borderRight:line,fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase"}},"Это не"),
        React.createElement("div",{style:{...cell,paddingTop:"var(--space-3)",paddingBottom:"var(--space-3)",background:dark?"transparent":"var(--surface-dossier)",color:"var(--cli-paper-200)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase"}},"Правильная категория")),
      Array.from({length:rows}).map((_,i)=>React.createElement("div",{key:i,style:{display:"grid",gridTemplateColumns:"1fr 1fr",borderTop:line}},
        React.createElement("div",{style:{...cell,borderRight:line}},
          isNot[i]?[React.createElement("strong",{key:"t",style:{display:"block",fontFamily:"var(--font-mono)",fontSize:"11px",letterSpacing:".1em",textTransform:"uppercase",color:"var(--role-stop)",marginBottom:"6px",fontWeight:400}},isNot[i].title),
            React.createElement("p",{key:"p",style:{fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--cli-red-700)"}},isNot[i].text)]:null),
        React.createElement("div",{style:cell},
          isThis[i]?[React.createElement("strong",{key:"t",style:{display:"block",fontFamily:"var(--font-mono)",fontSize:"11px",letterSpacing:".1em",textTransform:"uppercase",color:"var(--role-data)",marginBottom:"6px",fontWeight:400}},isThis[i].title),
            React.createElement("p",{key:"p",style:{fontSize:"var(--text-small)",color:dark?"var(--cli-paper-200)":"var(--text-body)"}},isThis[i].text)]:null)))));
}
