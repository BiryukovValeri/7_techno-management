import type * as React from "react";
export interface AntiCategoryRow { title: string; text: string }
/**
 * Mandatory anti-category block on all 7 sites. Source: Матрица_Анти_Категорий v1.0.
 * @startingPoint section="Technology site" subtitle="Anti-category block: это не / правильная категория" viewport="1280x520"
 */
export interface WhatItIsNotProps {
  /** Left column: false categories, phrased without defensiveness. */
  isNot?: AntiCategoryRow[];
  /** Right column: the correct perception category, row-aligned with isNot. */
  isThis?: AntiCategoryRow[];
  /** The public "Это не..." formula, set in display serif above the matrix. */
  formula?: string;
  tone?: "paper" | "dossier";
}
export declare function WhatItIsNot(props: WhatItIsNotProps): JSX.Element;
