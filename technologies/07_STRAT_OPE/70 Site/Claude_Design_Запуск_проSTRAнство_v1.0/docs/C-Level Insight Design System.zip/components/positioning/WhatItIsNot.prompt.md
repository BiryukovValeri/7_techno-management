The anti-category block every technology site must carry. Navigational, not a disclaimer.

```jsx
<WhatItIsNot formula="Не кадровая оценка директоров, не коучинг и не новая оргструктура."
  isNot={[{title:"Не HR-оценка",text:"Не аттестация первого круга."}]}
  isThis={[{title:"Роли и мандаты",text:"Какие функции видимы и кто имеет право решать."}]} />
```

Rules: never argue with the market, never sound defensive, keep rows aligned 1:1 so the correction is legible. Red is used for the label only, never as a fill.
