import type * as React from "react";
export interface MatrixCell { text: string; tone?: "stop" | "go" | "neutral"; strong?: boolean }
export interface MatrixRow { label: string; cells: Array<MatrixCell | string> }
export interface ComparisonMatrixProps {
  /** First entry is the row-label column header. */
  columns?: string[];
  rows?: MatrixRow[];
  /** 1-based index into the data columns to emphasise (the recommended option). */
  highlightColumn?: number;
  caption?: string;
}
export declare function ComparisonMatrix(props: ComparisonMatrixProps): JSX.Element;
