import type * as React from "react";
export interface CaseCardProps {
  /** Industry / context label. Never a client name unless approved. */
  sector: string;
  /** Scale marker, e.g. "6 директоров · производство". */
  scale?: string;
  situation: string;
  unmanageable: string;
  technology: string;
  firstStep: string;
  result: string;
  href?: string;
  linkLabel?: string;
}
export declare function CaseCard(props: CaseCardProps): JSX.Element;
