import React from "react";

/** Case as a horizontal / vertical flow of managerial states. Dark band form of CaseCard. */
export function CaseFlow({steps=[],tone="dossier",aside}){
  const dark=tone==="dossier";
  const accent={gap:"#e79a9a",go:"#7fc9c0"};
  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:aside?"minmax(280px,34%) 1fr":"1fr",gap:"var(--space-12)",alignItems:"stretch"}},
    aside||null,
    React.createElement("div",{style:{display:"grid",gap:"1px",background:dark?"var(--line-on-dossier)":"var(--cli-paper-500)",alignContent:"start"}},
      steps.map((s,i)=>React.createElement("div",{key:i,style:{background:dark?"var(--cli-navy-800)":"var(--surface-card)",padding:"var(--space-5) var(--space-6)",display:"grid",gridTemplateColumns:"150px 1fr",gap:"var(--space-6)",alignItems:"baseline"}},
        React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:s.state?accent[s.state]:(dark?"var(--cli-slate-300)":"var(--text-muted)")}},s.label),
        React.createElement("p",{style:{fontSize:"var(--text-small)",color:dark?"rgba(243,235,221,.88)":"var(--text-body)"}},s.text)))));
}
