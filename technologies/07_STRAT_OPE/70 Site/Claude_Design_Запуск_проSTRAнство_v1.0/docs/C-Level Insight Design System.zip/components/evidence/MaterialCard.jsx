import React from "react";

/** Material / artefact row: presentation, one-page, schema pack, article. */
export function MaterialCard({kind="PDF",title,description,meta,href,actionLabel="Скачать"}){
  return React.createElement("a",{href,style:{display:"grid",gridTemplateColumns:"auto 1fr auto",gap:"var(--space-6)",alignItems:"center",padding:"var(--space-5) var(--space-6)",background:"var(--surface-card)",border:"1px solid var(--cli-paper-500)",textDecoration:"none",color:"inherit",minHeight:"var(--touch-min)",transition:"var(--transition-control)"}},
    React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--accent-tech)",border:"1px solid var(--cli-copper-200)",padding:"6px 9px",whiteSpace:"nowrap"}},kind),
    React.createElement("span",null,
      React.createElement("span",{style:{display:"block",fontFamily:"var(--font-display)",fontSize:"var(--text-h4)",color:"var(--text-display)"}},title),
      description?React.createElement("span",{style:{display:"block",marginTop:"4px",fontSize:"var(--text-small)",color:"var(--text-muted)",maxWidth:"64ch"}},description):null),
    React.createElement("span",{style:{display:"grid",justifyItems:"end",gap:"4px"}},
      meta?React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:".1em",textTransform:"uppercase",color:"var(--text-muted)"}},meta):null,
      React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--cli-navy-800)"}},actionLabel+" ↓")));
}
