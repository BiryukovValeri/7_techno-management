Offers the one-page / presentation as an artefact. No email gate, no hidden paywall, no "diagnostics" disguised as a download.

```jsx
<OnePageBlock title="One-page технологии" description="Одна страница о том, что настраивает CLM."
  bullets={["Ядро и шесть слоёв","Четыре продукта","Вход в Диагностику"]} />
```
