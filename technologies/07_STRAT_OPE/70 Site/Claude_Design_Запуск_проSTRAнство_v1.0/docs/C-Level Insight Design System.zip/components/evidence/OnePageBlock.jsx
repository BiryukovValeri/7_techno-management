import React from "react";
import { Button } from "../core/Button.jsx";
/** One-page / presentation download band: an artefact offer, not a lead magnet. */
export function OnePageBlock({title,description,bullets=[],ctaLabel="Получить one-page",ctaHref="#one-page",secondary,preview,tone="paper"}){
  const dark=tone==="dossier";
  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:preview?"1fr minmax(260px,34%)":"1fr",gap:"var(--space-12)",alignItems:"center",padding:"var(--space-8)",border:dark?"1px solid var(--line-on-dossier)":"2px solid var(--line-strong)",background:dark?"var(--surface-dossier-raised)":"var(--surface-card)"}},
    React.createElement("div",null,
      React.createElement("h3",{style:{fontSize:"var(--text-h3)",color:dark?"var(--cli-paper-200)":"var(--text-display)",maxWidth:"26ch"}},title),
      description?React.createElement("p",{style:{marginTop:"var(--space-4)",fontSize:"var(--text-body-size)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)",maxWidth:"58ch"}},description):null,
      bullets.length?React.createElement("ul",{style:{margin:"var(--space-5) 0 0",padding:0,listStyle:"none",display:"grid",gap:"var(--space-2)"}},
        bullets.map((b,i)=>React.createElement("li",{key:i,style:{display:"grid",gridTemplateColumns:"18px 1fr",gap:"var(--space-3)",fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)"}},
          React.createElement("span",{style:{fontFamily:"var(--font-mono)",color:"var(--accent-tech)"}},"→"),React.createElement("span",null,b)))):null,
      React.createElement("div",{style:{display:"flex",gap:"var(--space-3)",marginTop:"var(--space-8)",flexWrap:"wrap"}},
        React.createElement(Button,{variant:dark?"onDark":"primary",href:ctaHref,trailing:"↓"},ctaLabel),
        secondary?React.createElement(Button,{variant:dark?"onDarkLine":"ghost",href:secondary.href},secondary.label):null)),
    preview||null);
}
