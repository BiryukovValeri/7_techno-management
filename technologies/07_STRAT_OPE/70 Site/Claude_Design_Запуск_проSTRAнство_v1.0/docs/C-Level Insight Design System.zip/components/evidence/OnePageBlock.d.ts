import type * as React from "react";
export interface OnePageBlockProps {
  title: string;
  description?: string;
  /** What is inside the artefact - route-marked lines. */
  bullets?: string[];
  ctaLabel?: string;
  ctaHref?: string;
  secondary?: { label: string; href: string };
  /** Optional artefact preview - a page thumbnail, never a stock image. */
  preview?: React.ReactNode;
  tone?: "paper" | "dossier";
}
export declare function OnePageBlock(props: OnePageBlockProps): JSX.Element;
