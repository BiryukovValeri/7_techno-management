import type * as React from "react";
export interface MaterialCardProps {
  /** Short mono kind marker: PDF, ONE-PAGE, PPTX, СХЕМЫ, СТАТЬЯ. */
  kind?: string;
  title: string;
  description?: string;
  /** Right-side meta, e.g. "12 страниц · 2.4 МБ". */
  meta?: string;
  href?: string;
  actionLabel?: string;
}
export declare function MaterialCard(props: MaterialCardProps): JSX.Element;
