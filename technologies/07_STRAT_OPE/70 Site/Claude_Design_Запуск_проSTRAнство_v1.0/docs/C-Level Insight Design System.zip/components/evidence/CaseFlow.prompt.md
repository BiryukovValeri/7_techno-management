The cinematic form of a case: a flow of managerial states across one dark band, with an optional scene image on the left.

```jsx
<CaseFlow steps={[{label:"Было неуправляемым",text:"…",state:"gap"},{label:"Стало управляемым",text:"…",state:"go"}]}
  aside={<div style={{position:"relative",minHeight:420}}><image-slot id="case-shot" shape="rect" /></div>} />
```

The `aside` is the only place a future image may appear inside an evidence block - and no visualization may appear in the same band.
