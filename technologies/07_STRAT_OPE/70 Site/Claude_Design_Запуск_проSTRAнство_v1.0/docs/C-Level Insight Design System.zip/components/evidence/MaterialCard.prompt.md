A row in the Materials section. Rows, not a card wall - materials are an index, not a product grid.

```jsx
<MaterialCard kind="ONE-PAGE" title="CLM: первый круг за одну страницу"
  description="Смысл технологии, четыре продукта и вход в Диагностику." meta="1 страница · PDF" href="#" />
```

The download mark is a typographic ↓ - the system has no icon set.
