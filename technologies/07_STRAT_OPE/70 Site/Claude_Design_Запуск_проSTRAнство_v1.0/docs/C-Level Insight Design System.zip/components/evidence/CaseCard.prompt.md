The five-part case structure required on every technology site. Proof of applicability, not a testimonial.

```jsx
<CaseCard sector="Производство" scale="6 директоров"
  situation="Выручка растёт, скорость решений падает."
  unmanageable="Каждое межфункциональное решение доходило до CEO."
  technology="CLM: пересборка первого круга."
  firstStep="Диагностика: карта ролей и точек ручной маршрутизации."
  result="Решения закреплены за мандатами, CEO вышел из маршрута." />
```

Never promise a numeric result that has not been approved. No "до / после" percentages without a source.
