import React from "react";

/** Case as proof of applicability: situation → unmanageable → technology → first step → became manageable. */
export function CaseCard({sector,scale,situation,unmanageable,technology,firstStep,result,href,linkLabel="Смотреть кейс"}){
  const rows=[["Ситуация",situation,null],["Было неуправляемым",unmanageable,"stop"],["Технология",technology,null],["Первый шаг",firstStep,"route"],["Стало управляемым",result,"go"]];
  const tone={stop:"var(--role-stop)",route:"var(--role-route)",go:"var(--role-go)"};
  return React.createElement("article",{style:{border:"1px solid var(--cli-paper-500)",background:"var(--surface-card)",boxShadow:"var(--shadow-card)",display:"grid",alignContent:"start"}},
    React.createElement("div",{style:{display:"flex",justifyContent:"space-between",gap:"var(--space-4)",padding:"var(--space-3) var(--space-5)",borderBottom:"1px solid var(--cli-paper-500)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--text-muted)"}},
      React.createElement("span",null,sector),scale?React.createElement("span",null,scale):null),
    React.createElement("div",{style:{padding:"var(--space-5)",display:"grid",gap:"var(--space-4)"}},
      rows.filter(r=>r[1]).map(([label,text,t])=>React.createElement("div",{key:label,style:{display:"grid",gridTemplateColumns:"146px 1fr",gap:"var(--space-4)",alignItems:"baseline"}},
        React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:t?tone[t]:"var(--text-muted)"}},label),
        React.createElement("p",{style:{fontSize:"var(--text-small)",color:"var(--text-body)"}},text)))),
    href?React.createElement("a",{href,style:{padding:"var(--space-4) var(--space-5)",borderTop:"1px solid var(--cli-paper-500)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--cli-navy-800)",textDecoration:"none",border:0,borderTop:"1px solid var(--cli-paper-500)",minHeight:"var(--touch-min)",display:"flex",alignItems:"center"}},linkLabel+" →"):null);
}
