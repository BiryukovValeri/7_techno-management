import type * as React from "react";
export interface CaseFlowStep {
  label: string;
  text: string;
  /** gap = what was unmanageable (red label); go = what became manageable (teal label). */
  state?: "gap" | "go";
}
export interface CaseFlowProps {
  steps?: CaseFlowStep[];
  tone?: "dossier" | "paper";
  /** Optional left column - the case scene image slot in cinematic bands. */
  aside?: React.ReactNode;
}
export declare function CaseFlow(props: CaseFlowProps): JSX.Element;
