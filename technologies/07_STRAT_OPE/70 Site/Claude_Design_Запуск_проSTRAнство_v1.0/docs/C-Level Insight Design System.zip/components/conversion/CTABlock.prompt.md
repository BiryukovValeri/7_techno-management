Closing band that leads to the paid Diagnostics. Diagnostics is the primary CTA on a technology site only - never in the gigasite header.

```jsx
<CTABlock title="Диагностика первого круга" body="Первичный диагноз, вердикт и право на STOP."
  terms={["Платный вход, не пресейл.","Результат не обещается до Диагностики."]} />
```

Never a small card, never two competing CTAs, never a countdown or scarcity device.
