import React from "react";
import { Button } from "../core/Button.jsx";
const label={display:"block",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--text-label)",marginBottom:"var(--space-2)"};
const field={width:"100%",minHeight:"var(--touch-min)",padding:"var(--space-3) var(--space-4)",background:"var(--cli-white)",border:"1px solid var(--line-hairline)",borderRadius:"var(--radius-xs)",fontFamily:"var(--font-sans)",fontSize:"var(--text-body-size)",color:"var(--text-body)",boxSizing:"border-box"};
/** Short Diagnostics request. Visible labels, six fields, no on-site diagnosis. */
export function RequestDiagnosticsForm({title="Заявка на Диагностику",note,onSubmit,submitLabel="Отправить заявку",state="idle",errors={},consentText="Согласен на обработку персональных данных."}){
  const err=(k)=>errors[k]?React.createElement("span",{style:{display:"block",marginTop:"6px",fontSize:"var(--text-small)",color:"var(--role-stop)"}},errors[k]):null;
  return React.createElement("form",{onSubmit,noValidate:true,style:{border:"2px solid var(--line-strong)",background:"var(--surface-card)",padding:"var(--space-8)",display:"grid",gap:"var(--space-5)",maxWidth:"620px"}},
    React.createElement("div",null,
      React.createElement("h3",{style:{fontSize:"var(--text-h3)"}},title),
      note?React.createElement("p",{style:{marginTop:"var(--space-3)",fontSize:"var(--text-small)",color:"var(--text-muted)"}},note):null),
    React.createElement("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--space-5)"}},
      React.createElement("div",null,React.createElement("label",{htmlFor:"rd-name",style:label},"Имя"),React.createElement("input",{id:"rd-name",name:"name",style:{...field,borderColor:errors.name?"var(--role-stop)":"var(--line-hairline)"},autoComplete:"name"}),err("name")),
      React.createElement("div",null,React.createElement("label",{htmlFor:"rd-company",style:label},"Компания"),React.createElement("input",{id:"rd-company",name:"company",style:field,autoComplete:"organization"}),err("company"))),
    React.createElement("div",{style:{display:"grid",gridTemplateColumns:"1fr 1fr",gap:"var(--space-5)"}},
      React.createElement("div",null,React.createElement("label",{htmlFor:"rd-role",style:label},"Роль"),React.createElement("input",{id:"rd-role",name:"role",style:field,placeholder:"CEO / COO / CFO"}),err("role")),
      React.createElement("div",null,React.createElement("label",{htmlFor:"rd-contact",style:label},"Контакт"),React.createElement("input",{id:"rd-contact",name:"contact",style:{...field,borderColor:errors.contact?"var(--role-stop)":"var(--line-hairline)"},placeholder:"E-mail или телефон"}),err("contact"))),
    React.createElement("div",null,React.createElement("label",{htmlFor:"rd-situation",style:label},"Коротко о ситуации"),
      React.createElement("textarea",{id:"rd-situation",name:"situation",rows:4,style:{...field,minHeight:"120px",resize:"vertical"}}),
      React.createElement("span",{style:{display:"block",marginTop:"6px",fontSize:"var(--text-small)",color:"var(--text-muted)"}},"3-4 строки. Полная диагностика не проводится на сайте.")),
    React.createElement("label",{htmlFor:"rd-consent",style:{display:"grid",gridTemplateColumns:"20px 1fr",gap:"var(--space-3)",alignItems:"start",fontSize:"var(--text-small)",color:"var(--text-muted)",minHeight:"var(--touch-min)"}},
      React.createElement("input",{id:"rd-consent",name:"consent",type:"checkbox",style:{width:"20px",height:"20px",accentColor:"var(--cli-navy-800)",marginTop:"2px"}}),
      React.createElement("span",null,consentText)),
    errors.consent?React.createElement("span",{style:{fontSize:"var(--text-small)",color:"var(--role-stop)"}},errors.consent):null,
    React.createElement("div",{style:{display:"flex",alignItems:"center",gap:"var(--space-5)",flexWrap:"wrap"}},
      React.createElement(Button,{variant:"primary",size:"lg",disabled:state==="sending"},state==="sending"?"Отправляем…":submitLabel),
      state==="sent"?React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",color:"var(--role-go)"}},"Заявка принята"):null));
}
