import React from "react";
import { Button } from "../core/Button.jsx";
/** Final CTA band on the paid Diagnostics. A full band, never a small card. */
export function CTABlock({eyebrow="Первый платный вход",title,body,primaryCta={label:"Запросить Диагностику",href:"#diagnostics"},secondaryCta,terms=[],tone="dossier",scene}){
  const dark=tone!=="paper";
  return React.createElement("section",{style:{position:"relative",overflow:"hidden",isolation:"isolate",...(dark
    ?{background:"var(--surface-dossier-deep)",backgroundImage:scene?"none":"var(--grid-dossier)",backgroundSize:"var(--grid-repeat)",color:"var(--text-on-dossier)"}
    :{background:"var(--surface-page)",backgroundImage:"var(--grid-paper)",backgroundSize:"var(--grid-repeat)"})}},
    scene?React.createElement("div",{style:{position:"absolute",inset:0,zIndex:0}},scene):null,
    scene?React.createElement("div",{style:{position:"absolute",inset:0,zIndex:1,background:"var(--scrim-bottom)",pointerEvents:"none"}}):null,
    React.createElement("div",{style:{position:"relative",zIndex:2,maxWidth:"var(--container)",margin:"0 auto",padding:"var(--band-py-tight) var(--gutter-desktop)",display:"grid",gridTemplateColumns:"1.3fr 1fr",gap:"var(--space-16)",alignItems:"end"}},
      React.createElement("div",null,
        React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-eyebrow)",textTransform:"uppercase",color:"var(--accent-tech)"}},eyebrow),
        React.createElement("h2",{style:{marginTop:"var(--space-4)",fontSize:"var(--text-h1)",lineHeight:"var(--leading-display)",maxWidth:"22ch",color:dark?"var(--cli-paper-200)":"var(--text-display)"}},title),
        body?React.createElement("p",{style:{marginTop:"var(--space-5)",fontSize:"var(--text-lead)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)",maxWidth:"48ch"}},body):null,
        React.createElement("div",{style:{display:"flex",gap:"var(--space-3)",marginTop:"var(--space-8)",flexWrap:"wrap"}},
          React.createElement(Button,{variant:dark?"onDark":"primary",size:"lg",href:primaryCta.href},primaryCta.label),
          secondaryCta?React.createElement(Button,{variant:dark?"onDarkLine":"ghost",size:"lg",href:secondaryCta.href},secondaryCta.label):null)),
      terms.length?React.createElement("div",{style:{borderTop:dark?"1px solid var(--line-on-dossier)":"1px solid var(--line-hairline)",paddingTop:"var(--space-4)",display:"grid",gap:"var(--space-3)"}},
        terms.map((t,i)=>React.createElement("div",{key:i,style:{display:"grid",gridTemplateColumns:"22px 1fr",gap:"var(--space-3)",fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)"}},
          React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",color:"var(--accent-tech)"}},String(i+1).padStart(2,"0")),
          React.createElement("span",null,t)))):null));
}
