The only form in the system. Six fields, visible labels, plain request handling - no CRM engine, no on-site diagnosis.

```jsx
<RequestDiagnosticsForm note="Ответ в течение двух рабочих дней." state={state}
  errors={{contact:"Укажите e-mail или телефон"}} onSubmit={handle} />
```

Never extend into a questionnaire, scoring, maturity test or radar - that is a hard platform prohibition.
