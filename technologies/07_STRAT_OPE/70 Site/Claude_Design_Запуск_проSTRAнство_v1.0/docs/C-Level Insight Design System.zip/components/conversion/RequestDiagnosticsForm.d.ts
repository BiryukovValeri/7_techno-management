import type * as React from "react";
/**
 * Short Diagnostics request: name, company, role, contact, situation, consent.
 * @startingPoint section="Technology site" subtitle="Diagnostics request form" viewport="700x760"
 */
export interface RequestDiagnosticsFormProps {
  title?: string;
  note?: string;
  onSubmit?: (e: React.FormEvent<HTMLFormElement>) => void;
  submitLabel?: string;
  state?: "idle" | "sending" | "sent";
  /** Field-keyed error messages: name, company, role, contact, situation, consent. */
  errors?: Record<string, string>;
  consentText?: string;
}
export declare function RequestDiagnosticsForm(props: RequestDiagnosticsFormProps): JSX.Element;
