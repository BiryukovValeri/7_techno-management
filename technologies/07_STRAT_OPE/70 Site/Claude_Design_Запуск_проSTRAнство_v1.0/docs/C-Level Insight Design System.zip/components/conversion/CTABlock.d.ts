import type * as React from "react";
export interface CtaTarget { label: string; href: string }
/**
 * The closing band on the paid Diagnostics.
 * @startingPoint section="Technology site" subtitle="Final CTA band on paid Diagnostics" viewport="1440x520"
 */
export interface CTABlockProps {
  eyebrow?: string;
  title: string;
  body?: string;
  primaryCta?: CtaTarget;
  secondaryCta?: CtaTarget;
  /** Honest conditions of the entry: what Diagnostics gives, what it does not promise, the right to STOP. */
  terms?: string[];
  tone?: "dossier" | "paper";
  /** Optional <image-slot> scene. Using it here consumes the site's one cinematic band. */
  scene?: React.ReactNode;
}
export declare function CTABlock(props: CTABlockProps): JSX.Element;
