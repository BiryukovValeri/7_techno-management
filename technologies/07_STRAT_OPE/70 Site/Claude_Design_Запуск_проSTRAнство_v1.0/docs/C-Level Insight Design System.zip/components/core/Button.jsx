import React from "react";

const base={display:"inline-flex",alignItems:"center",justifyContent:"center",gap:"var(--space-2)",minHeight:"var(--touch-min)",padding:"0 var(--space-6)",fontFamily:"var(--font-sans)",fontSize:"var(--text-small)",fontWeight:"var(--weight-semibold)",lineHeight:1,border:"1px solid transparent",borderRadius:"var(--radius-xs)",cursor:"pointer",textDecoration:"none",transition:"var(--transition-control)",whiteSpace:"nowrap"};
const skins={
  primary:{background:"var(--cli-navy-800)",color:"var(--cli-paper-200)"},
  accent:{background:"var(--accent-tech)",color:"#fff"},
  ghost:{background:"transparent",color:"var(--cli-navy-800)",borderColor:"var(--cli-navy-800)"},
  onDark:{background:"var(--cli-paper-200)",color:"var(--cli-navy-800)"},
  onDarkLine:{background:"transparent",color:"var(--cli-paper-200)",borderColor:"var(--line-on-dossier)"},
  quiet:{background:"transparent",color:"var(--text-muted)",padding:0,minHeight:"var(--touch-min)"}
};
const sizes={sm:{minHeight:"36px",padding:"0 var(--space-4)",fontSize:"var(--text-label-size)"},md:{},lg:{minHeight:"52px",padding:"0 var(--space-8)",fontSize:"var(--text-body-size)"}};

/** Primary action control. Rectangular by system rule - never pill-shaped. */
export function Button({variant="primary",size="md",href,children,disabled,trailing,style,...rest}){
  const Tag=href&&!disabled?"a":"button";
  const s={...base,...sizes[size],...skins[variant],...(disabled?{opacity:.5,cursor:"not-allowed"}:null),...style};
  return React.createElement(Tag,{href:href&&!disabled?href:undefined,disabled:Tag==="button"?disabled:undefined,style:s,...rest},
    children,
    trailing?React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"1em",opacity:.8}},trailing):null);
}
