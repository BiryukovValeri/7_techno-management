import type * as React from "react";
export interface ButtonProps extends React.HTMLAttributes<HTMLElement> {
  /** primary = navy fill; accent = per-technology accent; ghost = navy outline on paper; onDark / onDarkLine for dossier bands; quiet = inline text action. */
  variant?: "primary" | "accent" | "ghost" | "onDark" | "onDarkLine" | "quiet";
  size?: "sm" | "md" | "lg";
  /** Renders an <a> instead of a <button>. */
  href?: string;
  disabled?: boolean;
  /** Small typographic trailing mark, e.g. "→" or "↓". The system uses type marks, not an icon set. */
  trailing?: string;
  children?: React.ReactNode;
}
export declare function Button(props: ButtonProps): JSX.Element;
