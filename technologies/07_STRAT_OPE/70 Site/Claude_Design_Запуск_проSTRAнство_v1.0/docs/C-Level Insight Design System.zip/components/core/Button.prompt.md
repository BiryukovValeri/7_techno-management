Rectangular action control for CTA logic across all 7 technology sites; `primary` on paper, `onDark` on dossier bands.

```jsx
<Button variant="primary" href="#diagnostics">Запросить Диагностику</Button>
<Button variant="ghost" trailing="→">Посмотреть, как работает</Button>
<Button variant="onDark" size="lg">Получить one-page</Button>
```

Variants: primary / accent / ghost / onDark / onDarkLine / quiet. Sizes sm / md / lg (md and lg clear the 44px touch floor; sm is 36px - desktop-only, secondary rows). Never use `accent` and `primary` side by side: one primary action per band.
