Structural section wrapper: every major block on a technology site is a Band, never a floating card cluster.

```jsx
<Band tone="paperGrid" id="how" eyebrow="Как работает · продуктовая лестница"
  title="Диагностика → Сессия → Спринт 30-60-90 → Сопровождение" aside="Маршрут един для 7 технологий">
  <ProductLadder steps={steps} />
</Band>
```

Intentional addition (not in the source component list): the layout standard requires bands rather than card walls, and every other component sits inside one.
