import React from "react";

const roles={
  neutral:{color:"var(--text-muted)",borderColor:"var(--line-hairline)",background:"var(--cli-paper-200)"},
  route:{color:"var(--role-route)",borderColor:"var(--cli-copper-200)",background:"transparent"},
  data:{color:"var(--role-data)",borderColor:"var(--cli-teal-200)",background:"transparent"},
  stop:{color:"var(--role-stop)",borderColor:"var(--cli-red-200)",background:"transparent"},
  architecture:{color:"var(--role-architecture)",borderColor:"var(--cli-navy-800)",background:"transparent"},
  onDark:{color:"var(--cli-paper-200)",borderColor:"var(--line-on-dossier)",background:"transparent"}
};
/** Mono uppercase role label. Always names the meaning that a colour alone must not carry. */
export function Tag({role="neutral",children,style,...rest}){
  return React.createElement("span",{style:{display:"inline-flex",alignItems:"center",fontFamily:"var(--font-mono)",fontSize:"11px",letterSpacing:".1em",textTransform:"uppercase",padding:"5px 9px",border:"1px solid",borderRadius:"var(--radius-xs)",...roles[role],...style},...rest},children);
}
