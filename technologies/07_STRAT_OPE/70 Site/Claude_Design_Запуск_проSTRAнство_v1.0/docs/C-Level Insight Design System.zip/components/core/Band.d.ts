import type * as React from "react";
export interface BandProps {
  /** paperGrid carries the blueprint texture; dossier tones are the dark premium bands. Max two dark bands per page. */
  tone?: "paper" | "paperGrid" | "card" | "dossier" | "dossierGrid";
  id?: string;
  eyebrow?: string;
  title?: string;
  /** Right-aligned mono meta on the ruled head, e.g. "01 / 09". */
  aside?: string;
  width?: "container" | "wide" | "narrow";
  tight?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function Band(props: BandProps): JSX.Element;
