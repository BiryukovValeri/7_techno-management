import type * as React from "react";
export interface TagProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Functional role the tag names in words, so meaning is never colour-only. */
  role?: "neutral" | "route" | "data" | "stop" | "architecture" | "onDark";
  children?: React.ReactNode;
}
export declare function Tag(props: TagProps): JSX.Element;
