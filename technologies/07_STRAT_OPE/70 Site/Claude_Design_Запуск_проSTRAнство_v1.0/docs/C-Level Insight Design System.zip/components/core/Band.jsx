import React from "react";

const tones={
  paper:{background:"var(--surface-page)"},
  paperGrid:{background:"var(--surface-page)",backgroundImage:"var(--grid-paper)",backgroundSize:"var(--grid-repeat)"},
  card:{background:"var(--surface-page-alt)"},
  dossier:{background:"var(--surface-dossier)",color:"var(--text-on-dossier)"},
  dossierGrid:{background:"var(--surface-dossier-deep)",backgroundImage:"var(--grid-dossier)",backgroundSize:"var(--grid-repeat)",color:"var(--text-on-dossier)"}
};
/** Full-width layout band with a ruled head. The system's structural unit - not a card. */
export function Band({tone="paper",id,eyebrow,title,aside,width="container",tight,children,style}){
  const dark=tone.startsWith("dossier");
  const max=width==="wide"?"var(--container-wide)":width==="narrow"?"var(--container-narrow)":"var(--container)";
  return React.createElement("section",{id,style:{paddingTop:tight?"var(--band-py-tight)":"var(--band-py)",paddingBottom:tight?"var(--band-py-tight)":"var(--band-py)",...tones[tone],...style}},
    React.createElement("div",{style:{maxWidth:max,margin:"0 auto",padding:"0 var(--gutter-desktop)"}},
      (eyebrow||title||aside)?React.createElement("div",{style:{display:"grid",gridTemplateColumns:aside?"1fr auto":"1fr",gap:"var(--space-8)",alignItems:"end",paddingBottom:"var(--space-4)",marginBottom:"var(--space-10)",borderBottom:dark?"2px solid var(--line-on-dossier)":"2px solid var(--line-strong)"}},
        React.createElement("div",null,
          eyebrow?React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-eyebrow)",textTransform:"uppercase",color:dark?"var(--accent-tech)":"var(--text-muted)"}},eyebrow):null,
          title?React.createElement("h2",{style:{marginTop:"var(--space-3)",maxWidth:"26ch",color:dark?"var(--cli-paper-200)":"var(--text-display)"}},title):null),
        aside?React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)",whiteSpace:"nowrap"}},aside):null):null,
      children));
}
