Mono uppercase label that spells out a functional role (route / data / Stop) so colour never carries meaning alone.

```jsx
<Tag role="route">Первый платный вход</Tag>
<Tag role="stop">Разрыв</Tag>
<Tag role="data">Владелец данных</Tag>
```

Roles map 1:1 to the colour roles taken from the visualization legend. Never use as a decorative chip.
