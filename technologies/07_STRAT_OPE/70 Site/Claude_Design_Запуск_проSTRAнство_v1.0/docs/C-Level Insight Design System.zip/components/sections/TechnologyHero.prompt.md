The first screen of a technology site: schema-led (default), map-led, or a cinematic scene. Never a split "text left / picture right" decoration.

```jsx
<TechnologyHero variant="schema" eyebrow="Клиентский слой · Ядро технологии"
  title="Первый круг как система управления"
  formula="Роли, мандаты, решения, данные, ритмы и ответственность собираются вокруг результата."
  notes={["Технология настройки C-level-ядра, а не оценка директоров."]}
  visualization={<VisualizationShowcase items={[viz01]} />} nextHint="Далее · что открывает технология" />
```

One hero per site. `variant="scene"` requires an `<image-slot>` child and consumes the site's single cinematic band.
