"Что открывает технология" - the opportunity, stated as a possibility, never as a diagnosis or a fear.

```jsx
<OpportunityBlock items={opportunities} />
<OpportunityBlock mode="accordion" items={layers} openId={open} onToggle={setOpen} />
```

Copy rule: each item names what becomes manageable, not what is broken.
