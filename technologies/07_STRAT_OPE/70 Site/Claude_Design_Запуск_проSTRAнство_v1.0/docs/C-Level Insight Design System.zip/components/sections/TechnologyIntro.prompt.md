States what the technology is, once, and indexes its layers. Use directly after the hero.

```jsx
<Band tone="paper" eyebrow="Ядро технологии" title="Что настраивается в первом круге">
  <TechnologyIntro statement="CLM настраивает первый управленческий круг, а не оценивает директоров."
    layers={[{title:"Роли",text:"Какие управленческие функции должны быть видимы"}]} />
</Band>
```

Max 6 layers - beyond that use the vertical accordion form inside OpportunityBlock.
