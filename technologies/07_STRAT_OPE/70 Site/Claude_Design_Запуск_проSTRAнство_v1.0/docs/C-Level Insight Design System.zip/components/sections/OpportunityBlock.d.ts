import type * as React from "react";
export interface OpportunityItem { id?: string; title: string; text: string }
export interface OpportunityBlockProps {
  items?: OpportunityItem[];
  /** cells = 2-4 equal cells in one band; accordion = vertical accordion for 5+ layers. */
  mode?: "cells" | "accordion";
  openId?: string;
  onToggle?: (id?: string) => void;
}
export declare function OpportunityBlock(props: OpportunityBlockProps): JSX.Element;
