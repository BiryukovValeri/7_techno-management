import type * as React from "react";
export interface HeroCta { label: string; href: string }
/**
 * Technology-site first screen. A hero is a visual event, never a text card.
 * @startingPoint section="Technology site" subtitle="Hero: schema / map / scene dramaturgy" viewport="1440x700"
 */
export interface TechnologyHeroProps {
  /** schema = the ready visualization is the hero object (base direction); map = 7-technology control panel; scene = full-bleed future image + scrim. */
  variant?: "schema" | "map" | "scene";
  eyebrow?: string;
  title: string;
  /** One strong benefit formula, 1-2 lines. */
  formula?: string;
  primaryCta?: HeroCta;
  secondaryCta?: HeroCta | null;
  /** Up to 3 numbered dossier notes under the CTAs. */
  notes?: string[];
  /** The VisualizationShowcase / plate for variant="schema". */
  visualization?: React.ReactNode;
  /** Map nodes for variant="map", or the <image-slot> scene for variant="scene". */
  children?: React.ReactNode;
  /** Mono hint at the bottom edge pointing to the next block. */
  nextHint?: string;
}
export declare function TechnologyHero(props: TechnologyHeroProps): JSX.Element;
