import type * as React from "react";
export interface TechnologyLayer { title: string; text: string }
export interface TechnologyIntroProps {
  /** The one-sentence core of the technology, set in display serif. */
  statement: string;
  body?: string[];
  /** The technology's layers as a ruled numbered index (CLM: roles, mandates, decisions, data, rhythms, accountability). */
  layers?: TechnologyLayer[];
  /** Optional accent-ruled aside, e.g. the category correction. */
  aside?: string;
}
export declare function TechnologyIntro(props: TechnologyIntroProps): JSX.Element;
