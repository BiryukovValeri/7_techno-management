"Когда уместна" - situations where the technology applies, with an honest "not now" column.

```jsx
<SituationBlock situations={["Сильные директора есть, управляемого круга нет."]}
  notApplicable={["Первый круг ещё не сформирован как состав."]} />
```

Never phrase situations as symptoms or as a medical picture. No scoring, no test.
