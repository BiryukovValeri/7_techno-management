import React from "react";

/** Editorial dossier intro: the technology's core stated once, with its layers listed as a ruled index. */
export function TechnologyIntro({statement,body=[],layers=[],aside}){
  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:"minmax(320px,46%) 1fr",gap:"var(--space-16)",alignItems:"start"}},
    React.createElement("div",null,
      React.createElement("p",{style:{fontFamily:"var(--font-display)",fontSize:"var(--text-h3)",lineHeight:"var(--leading-title)",color:"var(--text-display)",maxWidth:"26ch"}},statement),
      body.map((p,i)=>React.createElement("p",{key:i,style:{marginTop:"var(--space-5)",fontSize:"var(--text-body-size)",color:"var(--text-muted)",maxWidth:"var(--measure-body)"}},p)),
      aside?React.createElement("p",{style:{marginTop:"var(--space-8)",paddingLeft:"var(--space-5)",borderLeft:"2px solid var(--accent-tech)",fontSize:"var(--text-small)",color:"var(--text-muted)",maxWidth:"46ch"}},aside):null),
    layers.length?React.createElement("div",{style:{borderTop:"2px solid var(--line-strong)"}},
      layers.map((l,i)=>React.createElement("div",{key:l.title,style:{display:"grid",gridTemplateColumns:"48px 1fr",gap:"var(--space-4)",padding:"var(--space-5) 0",borderBottom:"1px solid var(--line-hairline)",alignItems:"baseline"}},
        React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",color:"var(--accent-tech)"}},String(i+1).padStart(2,"0")),
        React.createElement("div",null,
          React.createElement("h3",{style:{fontSize:"var(--text-h4)"}},l.title),
          React.createElement("p",{style:{marginTop:"6px",fontSize:"var(--text-small)",color:"var(--text-muted)",maxWidth:"56ch"}},l.text))))):null);
}
