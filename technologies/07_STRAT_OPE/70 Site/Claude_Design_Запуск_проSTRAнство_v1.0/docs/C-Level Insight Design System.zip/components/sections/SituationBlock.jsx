import React from "react";

/** "Когда уместна": situations in which the technology applies, as a ruled list with route markers. */
export function SituationBlock({situations=[],notApplicable=[]}){
  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:notApplicable.length?"1.35fr 1fr":"1fr",gap:"var(--space-12)",alignItems:"start"}},
    React.createElement("div",null,
      React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:"var(--role-route)",marginBottom:"var(--space-4)"}},"Уместна, когда"),
      React.createElement("div",{style:{borderTop:"1px solid var(--line-hairline)"}},
        situations.map((s,i)=>React.createElement("div",{key:i,style:{display:"grid",gridTemplateColumns:"26px 1fr",gap:"var(--space-4)",padding:"var(--space-4) 0",borderBottom:"1px solid var(--line-hairline)"}},
          React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",color:"var(--role-route)"}},"→"),
          React.createElement("p",{style:{fontSize:"var(--text-body-size)",maxWidth:"58ch"}},s))))),
    notApplicable.length?React.createElement("div",{style:{border:"1px solid var(--cli-red-200)",background:"var(--surface-card)",padding:"var(--space-6)"}},
      React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:"var(--role-stop)",marginBottom:"var(--space-4)"}},"Не время для технологии"),
      React.createElement("div",{style:{display:"grid",gap:"var(--space-3)"}},
        notApplicable.map((s,i)=>React.createElement("p",{key:i,style:{fontSize:"var(--text-small)",color:"var(--text-muted)"}},s)))):null);
}
