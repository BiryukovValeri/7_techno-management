import React from "react";

/** "What the technology opens": 2-4 opportunities as equal cells in one band, plus an optional vertical accordion. */
export function OpportunityBlock({items=[],mode="cells",openId,onToggle}){
  if(mode==="accordion") return React.createElement("div",{style:{borderTop:"2px solid var(--line-strong)"}},
    items.map((it,i)=>{const open=openId?it.id===openId:i===0;
      return React.createElement("div",{key:it.id||it.title,style:{borderBottom:"1px solid var(--line-hairline)",background:"var(--surface-card)"}},
        React.createElement("button",{type:"button",onClick:onToggle?()=>onToggle(it.id):undefined,"aria-expanded":open,
          style:{width:"100%",appearance:"none",background:"transparent",border:0,cursor:"pointer",textAlign:"left",display:"grid",gridTemplateColumns:"48px 1fr 24px",gap:"var(--space-4)",alignItems:"center",padding:"var(--space-5) var(--space-6)",minHeight:"var(--touch-min)"}},
          React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",color:"var(--accent-tech)"}},String(i+1).padStart(2,"0")),
          React.createElement("span",{style:{fontFamily:"var(--font-display)",fontSize:"var(--text-h4)",color:"var(--text-display)"}},it.title),
          React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"18px",color:"var(--text-muted)"}},open?"–":"+")),
        open?React.createElement("div",{style:{padding:"0 var(--space-6) var(--space-6) calc(var(--space-6) + 48px + var(--space-4))",maxWidth:"70ch"}},
          React.createElement("p",{style:{fontSize:"var(--text-small)",color:"var(--text-muted)"}},it.text)):null);}));

  return React.createElement("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(240px,1fr))",gap:0,border:"1px solid var(--line-hairline)",background:"var(--surface-card)"}},
    items.map((it,i)=>React.createElement("div",{key:it.title,style:{padding:"var(--space-6)",borderRight:i<items.length-1?"1px solid var(--line-hairline)":"none",display:"grid",gap:"var(--space-3)",alignContent:"start",position:"relative"}},
      React.createElement("span",{style:{position:"absolute",top:0,left:0,right:0,height:"3px",background:"var(--accent-tech)"}}),
      React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",color:"var(--text-muted)"}},String(i+1).padStart(2,"0")),
      React.createElement("h3",{style:{fontSize:"var(--text-h4)"}},it.title),
      React.createElement("p",{style:{fontSize:"var(--text-small)",color:"var(--text-muted)"}},it.text))));
}
