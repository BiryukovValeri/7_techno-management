import type * as React from "react";
export interface SituationBlockProps {
  /** Recognisable managerial situations, phrased from the client's reality. */
  situations?: string[];
  /** Honest "not now" cases. Keeps Diagnostics from reading as a presale. */
  notApplicable?: string[];
}
export declare function SituationBlock(props: SituationBlockProps): JSX.Element;
