import React from "react";
import { Button } from "../core/Button.jsx";
/**
 * First screen of a technology site. Three dramaturgies:
 * schema (the visualization IS the hero object), map (7-technology control panel), scene (full-bleed image + scrim).
 */
export function TechnologyHero({variant="schema",eyebrow,title,formula,primaryCta={label:"Запросить Диагностику",href:"#diagnostics"},secondaryCta={label:"Посмотреть, как работает",href:"#how"},notes=[],visualization,children,nextHint}){
  const dark=variant!=="schema";
  const head=React.createElement("div",null,
    eyebrow?React.createElement("div",{style:dark
      ?{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-eyebrow)",textTransform:"uppercase",color:"var(--accent-tech)",display:"flex",alignItems:"center",gap:"12px"}
      :{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-eyebrow)",textTransform:"uppercase",color:"var(--text-muted)",display:"inline-block",paddingBottom:"10px",borderBottom:"2px solid var(--accent-tech)"}},
      dark?[React.createElement("i",{key:"i",style:{width:"40px",height:"2px",background:"var(--accent-tech)",display:"block"}}),eyebrow]:eyebrow):null,
    React.createElement("h1",{style:{fontSize:variant==="scene"?"var(--text-hero-lg)":"var(--text-hero)",lineHeight:"var(--leading-display)",margin:"var(--space-6) 0 0",maxWidth:"16ch",color:dark?"var(--cli-paper-200)":"var(--text-display)",textWrap:"balance"}},title),
    formula?React.createElement("p",{style:{marginTop:"var(--space-5)",fontSize:"var(--text-lead)",lineHeight:1.55,maxWidth:"46ch",color:dark?"var(--text-on-dossier-muted)":"var(--cli-slate-600)"}},formula):null,
    React.createElement("div",{style:{display:"flex",gap:"var(--space-3)",marginTop:"var(--space-8)",flexWrap:"wrap"}},
      React.createElement(Button,{variant:variant==="scene"?"onDark":dark?"accent":"primary",href:primaryCta.href},primaryCta.label),
      secondaryCta?React.createElement(Button,{variant:dark?"onDarkLine":"ghost",href:secondaryCta.href,trailing:"→"},secondaryCta.label):null),
    notes.length?React.createElement("div",{style:{marginTop:"var(--space-10)",borderTop:dark?"1px solid var(--line-on-dossier)":"1px solid var(--line-hairline)",paddingTop:"var(--space-4)",display:"grid",gap:"var(--space-3)"}},
      notes.map((n,i)=>React.createElement("div",{key:i,style:{display:"grid",gridTemplateColumns:"26px 1fr",gap:"var(--space-3)",fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)"}},
        React.createElement("b",{style:{fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".08em",color:"var(--accent-tech)",fontWeight:400,paddingTop:"2px"}},String(i+1).padStart(2,"0")),
        React.createElement("p",null,n)))):null);

  if(variant==="scene") return React.createElement("section",{style:{position:"relative",minHeight:"var(--hero-min-h)",background:"var(--cli-navy-900)",overflow:"hidden",isolation:"isolate",display:"grid",alignItems:"end"}},
    React.createElement("div",{style:{position:"absolute",inset:0,zIndex:0}},children),
    React.createElement("div",{style:{position:"absolute",inset:0,zIndex:1,background:"var(--scrim-left)",pointerEvents:"none"}}),
    React.createElement("div",{style:{position:"absolute",inset:0,zIndex:1,background:"var(--scrim-bottom)",pointerEvents:"none"}}),
    React.createElement("div",{style:{position:"relative",zIndex:2,maxWidth:"var(--container-wide)",width:"100%",margin:"0 auto",padding:"var(--space-24) var(--gutter-desktop) var(--space-16)"}},
      React.createElement("div",{style:{maxWidth:"58ch"}},head)));

  return React.createElement("section",{style:{position:"relative",minHeight:"var(--hero-min-h)",...(dark
    ?{background:"var(--surface-dossier-deep)",backgroundImage:"var(--grid-dossier)",backgroundSize:"var(--grid-repeat)",color:"var(--text-on-dossier)"}
    :{background:"var(--surface-page)",backgroundImage:"var(--grid-paper)",backgroundSize:"var(--grid-repeat)"})}},
    React.createElement("div",{style:{maxWidth:"var(--container-wide)",margin:"0 auto",padding:"var(--space-12) var(--gutter-desktop) var(--space-16)",display:"grid",gridTemplateColumns:"minmax(340px,38%) 1fr",gap:"var(--space-16)",alignItems:variant==="map"?"center":"start"}},
      head,
      React.createElement("div",null,visualization||children)),
    nextHint?React.createElement("div",{style:{maxWidth:"var(--container-wide)",margin:"0 auto",padding:"0 var(--gutter-desktop) var(--space-10)",display:"flex",alignItems:"center",gap:"var(--space-4)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)"}},
      React.createElement("span",null,nextHint),
      React.createElement("i",{style:{flex:1,height:"1px",background:dark?"var(--line-on-dossier)":"var(--line-hairline)"}})):null);
}
