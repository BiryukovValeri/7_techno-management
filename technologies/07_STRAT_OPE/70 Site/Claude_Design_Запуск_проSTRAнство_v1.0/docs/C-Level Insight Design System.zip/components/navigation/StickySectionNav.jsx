import React from "react";

/** Sticky rail marking the reader's position on a long technology page. */
export function StickySectionNav({items=[],activeId,onSelect,orientation="vertical",label="Разделы страницы"}){
  const horizontal=orientation==="horizontal";
  return React.createElement("nav",{"aria-label":label,style:horizontal
    ?{position:"sticky",top:0,zIndex:5,display:"flex",gap:0,overflowX:"auto",background:"var(--surface-page)",borderBottom:"1px solid var(--line-hairline)"}
    :{position:"sticky",top:"var(--space-8)",display:"grid",gap:"2px",borderLeft:"2px solid var(--line-hairline)"}},
    items.map(it=>{const active=it.id===activeId;
      return React.createElement("a",{key:it.id,href:"#"+it.id,"aria-current":active?"true":undefined,
        onClick:onSelect?(e)=>{e.preventDefault();onSelect(it.id);}:undefined,
        style:{display:"flex",alignItems:"center",minHeight:"var(--touch-min)",padding:horizontal?"0 var(--space-5)":"10px var(--space-4)",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:".1em",textTransform:"uppercase",whiteSpace:"nowrap",textDecoration:"none",
          color:active?"var(--cli-navy-800)":"var(--text-muted)",
          background:active&&!horizontal?"var(--cli-paper-100)":"transparent",
          border:0,
          marginLeft:horizontal?0:"-2px",
          borderLeft:horizontal?"none":"2px solid "+(active?"var(--accent-tech)":"transparent"),
          borderBottom:horizontal?"2px solid "+(active?"var(--accent-tech)":"transparent"):"none",
          transition:"var(--transition-control)"}},it.label);}));
}
