import type * as React from "react";
export interface SectionNavItem { id: string; label: string }
export interface StickySectionNavProps {
  items?: SectionNavItem[];
  activeId?: string;
  onSelect?: (id: string) => void;
  /** vertical rail on desktop; horizontal scrolling strip is the mobile form. */
  orientation?: "vertical" | "horizontal";
  label?: string;
}
export declare function StickySectionNav(props: StickySectionNavProps): JSX.Element;
