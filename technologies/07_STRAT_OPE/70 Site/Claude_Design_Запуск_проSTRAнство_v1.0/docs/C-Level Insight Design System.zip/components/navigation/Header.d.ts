import type * as React from "react";
export interface HeaderLink { label: string; href: string }
/**
 * Technology-site header.
 * @startingPoint section="Technology site" subtitle="Header with technology mark and Diagnostics CTA" viewport="1440x110"
 */
export interface HeaderProps {
  technology?: string;
  /** Two-digit technology number, 01-07. */
  index?: string;
  platform?: string;
  links?: HeaderLink[];
  ctaLabel?: string;
  ctaHref?: string;
  /** paper = light band; dossier = dark band (use over a cinematic hero). */
  tone?: "paper" | "dossier";
}
export declare function Header(props: HeaderProps): JSX.Element;
