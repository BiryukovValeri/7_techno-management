import React from "react";
import { Button } from "../core/Button.jsx";

/** Technology-site header: platform mark, technology name, section links, Diagnostics CTA. */
export function Header({technology="Управление Директорами / CLM",index="04",platform="C-Level Insight",links=[],ctaLabel="Запросить Диагностику",ctaHref="#diagnostics",tone="paper"}){
  const dark=tone==="dossier";
  return React.createElement("header",{style:{background:dark?"var(--surface-dossier)":"var(--surface-page)",borderBottom:dark?"1px solid var(--line-on-dossier)":"1px solid var(--line-hairline)",position:"relative"}},
    React.createElement("div",{style:{maxWidth:"var(--container-wide)",margin:"0 auto",padding:"18px var(--gutter-desktop)",display:"flex",alignItems:"center",justifyContent:"space-between",gap:"var(--space-8)",flexWrap:"wrap"}},
      React.createElement("a",{href:"#top",style:{textDecoration:"none",border:0,display:"block"}},
        React.createElement("span",{style:{display:"block",fontFamily:"var(--font-display)",fontSize:"18px",fontWeight:"var(--weight-bold)",color:dark?"var(--cli-paper-200)":"var(--text-display)"}},technology),
        React.createElement("span",{style:{display:"block",marginTop:"4px",fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:"var(--tracking-eyebrow)",textTransform:"uppercase",color:"var(--accent-tech)"}},platform+" · ТЕХНОЛОГИЯ "+index)),
      React.createElement("nav",{style:{display:"flex",alignItems:"center",gap:"var(--space-6)",flexWrap:"wrap"}},
        links.map(l=>React.createElement("a",{key:l.label,href:l.href,style:{fontSize:"var(--text-small)",color:dark?"var(--text-on-dossier-muted)":"var(--text-muted)",textDecoration:"none",border:0,minHeight:"var(--touch-min)",display:"inline-flex",alignItems:"center"}},l.label)),
        React.createElement(Button,{variant:dark?"onDark":"primary",href:ctaHref},ctaLabel))));
}
