Top navigation of a technology site. Diagnostics is the CTA here (on the gigasite header it must NOT be).

```jsx
<Header technology="Управление Директорами / CLM" index="04"
  links={[{label:"Как работает",href:"#how"},{label:"Визуализации",href:"#viz"},{label:"Кейсы",href:"#cases"}]} />
```

`tone="dossier"` when the header sits over a dark cinematic hero. Never more than 5 links.
