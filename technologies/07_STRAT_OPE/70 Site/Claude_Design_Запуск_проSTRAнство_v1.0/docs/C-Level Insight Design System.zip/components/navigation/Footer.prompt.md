Dossier-dark footer that carries the platform link, materials, author layer and the 7-technology map.

```jsx
<Footer columns={[{title:"Технология",links:[{label:"Как работает",href:"#how"}]}]}
  technologies={[{index:"04",name:"CLM",href:"#",active:true}]} note="Первый платный вход - Диагностика." />
```

The technology map in the footer is the one "control room" element allowed on every site. Do not add social icon rows - the system has no icon set.
