Position marker for a long technology page. Vertical rail on desktop, horizontal strip on mobile.

```jsx
<StickySectionNav items={sections} activeId="viz" onSelect={setActive} />
<StickySectionNav items={sections} activeId="viz" orientation="horizontal" />
```

Max 8 items. Labels are mono uppercase and short - it is a rail, not a menu.
