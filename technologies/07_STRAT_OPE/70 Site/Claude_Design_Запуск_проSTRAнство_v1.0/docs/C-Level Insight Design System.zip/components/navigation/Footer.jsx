import React from "react";

/** Site footer: links back to the gigasite, the author layer, materials and the 7-technology map. */
export function Footer({platform="C-Level Insight",technology="Управление Директорами / CLM",columns=[],technologies=[],note}){
  return React.createElement("footer",{style:{background:"var(--surface-dossier-deep)",backgroundImage:"var(--grid-dossier)",backgroundSize:"var(--grid-repeat)",color:"var(--text-on-dossier)",paddingTop:"var(--space-16)",paddingBottom:"var(--space-10)"}},
    React.createElement("div",{style:{maxWidth:"var(--container-wide)",margin:"0 auto",padding:"0 var(--gutter-desktop)"}},
      React.createElement("div",{style:{display:"grid",gridTemplateColumns:"minmax(240px,1fr) 2fr",gap:"var(--space-16)",paddingBottom:"var(--space-10)",borderBottom:"1px solid var(--line-on-dossier)"}},
        React.createElement("div",null,
          React.createElement("div",{style:{fontFamily:"var(--font-display)",fontSize:"var(--text-h4)",color:"var(--cli-paper-200)"}},platform),
          React.createElement("div",{style:{marginTop:"6px",fontFamily:"var(--font-mono)",fontSize:"var(--text-micro)",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:"var(--accent-tech)"}},technology),
          note?React.createElement("p",{style:{marginTop:"var(--space-5)",fontSize:"var(--text-small)",color:"var(--text-on-dossier-muted)",maxWidth:"34ch"}},note):null),
        React.createElement("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(150px,1fr))",gap:"var(--space-8)"}},
          columns.map(c=>React.createElement("div",{key:c.title},
            React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:"var(--cli-slate-300)",marginBottom:"var(--space-4)"}},c.title),
            React.createElement("div",{style:{display:"grid",gap:"var(--space-1)"}},
              c.links.map(l=>React.createElement("a",{key:l.label,href:l.href,style:{fontSize:"var(--text-small)",color:"var(--cli-paper-200)",textDecoration:"none",border:0,minHeight:"var(--touch-min)",display:"flex",alignItems:"center"}},l.label))))))),
      technologies.length?React.createElement("div",{style:{paddingTop:"var(--space-8)"}},
        React.createElement("div",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:"var(--tracking-label)",textTransform:"uppercase",color:"var(--cli-slate-300)",marginBottom:"var(--space-4)"}},"Карта технологий · 7"),
        React.createElement("div",{style:{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(170px,1fr))",gap:"1px",background:"var(--line-on-dossier)"}},
          technologies.map(t=>React.createElement("a",{key:t.name,href:t.href,style:{background:t.active?"var(--cli-paper-200)":"var(--cli-navy-800)",color:t.active?"var(--cli-navy-800)":"var(--cli-paper-200)",textDecoration:"none",border:0,padding:"var(--space-4)",minHeight:"var(--touch-min)",display:"grid",gap:"4px",alignContent:"center"}},
            React.createElement("span",{style:{fontFamily:"var(--font-mono)",fontSize:"10px",letterSpacing:".1em",color:t.active?"var(--accent-tech)":"var(--cli-slate-300)"}},t.index),
            React.createElement("span",{style:{fontSize:"var(--text-small)",fontWeight:"var(--weight-medium)"}},t.name))))):null));
}
