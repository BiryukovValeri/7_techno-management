import type * as React from "react";
export interface FooterLink { label: string; href: string }
export interface FooterColumn { title: string; links: FooterLink[] }
export interface FooterTechnology { index: string; name: string; href: string; active?: boolean }
export interface FooterProps {
  platform?: string;
  technology?: string;
  columns?: FooterColumn[];
  /** All 7 technologies. Mark the current one active - the footer doubles as the platform map. */
  technologies?: FooterTechnology[];
  note?: string;
}
export declare function Footer(props: FooterProps): JSX.Element;
