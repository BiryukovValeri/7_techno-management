---
name: c-level-insight-design
description: Use this skill to generate well-branded interfaces and assets for C-Level Insight, either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for protoyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

## Where to look first

1. `readme.md` — brand context, CONTENT FUNDAMENTALS, VISUAL FOUNDATIONS, ICONOGRAPHY, component index, known gaps.
2. `DESIGN_SYSTEM_V1.md` — the approved v1.0 candidate: mandatory page structure, visualization rules, future-image rules, mobile rules, WordPress constraints, Self-QA.
3. `directions/README.md` — the three explored directions and why Executive Blueprint won.
4. `ui_kits/technology-site-clm/` — the reference technology site to copy from.
5. `styles.css` + `tokens/` — the only styling source. Never invent colours, sizes or radii.

## Non-negotiables

- Не generic consulting template, не SaaS-dashboard, не BI-панель, не HR-платформа, не коучинговый сайт.
- Никакой медицинской метафоры. Никакого публичного scoring, радара, теста зрелости или диагноза.
- Визуализации (готовые схемы) и будущие изображения — разные классы активов. Никогда в одной секции.
- Функциональный цвет всегда сопровождается текстовой меткой.
- Эмодзи не используются. Иконочного набора нет — служебные знаки типографические (→ ↓ ↗ ↑ + – × ·).
- Логотипа в источниках нет: имя набирается типографикой. Не рисовать знак.
- Body text ≥ 16px, touch targets ≥ 44px, контраст ≥ 4.5:1, отрицательный letter-spacing запрещён, font-size не масштабируется от viewport.
