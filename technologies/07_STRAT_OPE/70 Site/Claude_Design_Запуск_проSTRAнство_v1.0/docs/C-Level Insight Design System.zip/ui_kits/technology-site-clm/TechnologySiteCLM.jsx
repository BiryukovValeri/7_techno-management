/* CLM technology site — desktop screen. Composes the design-system components only. */
const { Header, Footer, StickySectionNav, TechnologyHero, TechnologyIntro, OpportunityBlock, SituationBlock,
  WhatItIsNot, ComparisonMatrix, ProductLadder, VisualizationShowcase, CaseCard, CaseFlow, MaterialCard,
  OnePageBlock, CTABlock, RequestDiagnosticsForm, Band, Button } = window.CLevelInsightDesignSystem_27a32f;

function TechnologySiteCLM() {
  const d = window.CLM;
  const [active, setActive] = React.useState("hero");
  const [viz, setViz] = React.useState(0);
  const [layer, setLayer] = React.useState("o1");
  const [ladder, setLadder] = React.useState(0);
  const [state, setState] = React.useState("idle");
  const [errors, setErrors] = React.useState({});

  function submit(e) {
    e.preventDefault();
    const fd = new FormData(e.target);
    const next = {};
    if (!fd.get("name")) next.name = "Укажите имя";
    if (!fd.get("contact")) next.contact = "Укажите e-mail или телефон";
    if (!fd.get("consent")) next.consent = "Требуется согласие на обработку данных";
    setErrors(next);
    if (Object.keys(next).length) return;
    setState("sending");
    setTimeout(() => setState("sent"), 700);
  }

  return (
    <div id="top">
      <Header technology={d.technology} index={d.index} links={d.navLinks} />
      <TechnologyHero
        eyebrow={d.hero.eyebrow}
        title={d.hero.title}
        formula={d.hero.formula}
        notes={d.hero.notes}
        nextHint={d.hero.nextHint}
        visualization={<VisualizationShowcase items={[d.viz[0]]} />}
      />

      <div style={{ background: "var(--surface-page)" }}>
        <div style={{ maxWidth: "var(--container-wide)", margin: "0 auto", padding: "0 var(--gutter-desktop)", display: "grid", gridTemplateColumns: "210px 1fr", gap: "var(--space-16)", alignItems: "start" }}>
          <div style={{ paddingTop: "var(--band-py-tight)" }}>
            <StickySectionNav items={d.sections} activeId={active} onSelect={setActive} />
          </div>
          <div>
            <Band tone="paper" id="core" eyebrow="Ядро технологии" title="Что настраивается в первом круге" aside="Шесть слоёв" width="wide" tight style={{ paddingLeft: 0, paddingRight: 0 }}>
              <TechnologyIntro statement={d.intro.statement} body={d.intro.body} aside={d.intro.aside} layers={d.intro.layers} />
            </Band>

            <Band tone="paper" id="opportunity" eyebrow="Что открывает технология" title="Что становится управляемым" width="wide" tight style={{ paddingLeft: 0, paddingRight: 0 }}>
              <OpportunityBlock items={d.opportunities.slice(0, 4)} />
              <div style={{ marginTop: "var(--space-10)" }}>
                <OpportunityBlock mode="accordion" items={d.opportunities} openId={layer} onToggle={setLayer} />
              </div>
            </Band>

            <Band tone="paper" id="situation" eyebrow="Когда уместна" title="Управленческие ситуации технологии" width="wide" tight style={{ paddingLeft: 0, paddingRight: 0 }}>
              <SituationBlock situations={d.situations} notApplicable={d.notApplicable} />
            </Band>
          </div>
        </div>
      </div>

      <Band tone="paperGrid" id="isnot" eyebrow="Что это / что это не" title="Правильная категория восприятия" aside="Матрица анти-категорий" width="wide">
        <WhatItIsNot
          formula="Не кадровая оценка директоров, не коучинг и не новая оргструктура."
          isNot={d.isNot}
          isThis={d.isThis}
        />
        <div style={{ marginTop: "var(--space-16)" }}>
          <ComparisonMatrix
            columns={["Критерий", "Ручной маршрут", "Управляемый контур"]}
            highlightColumn={2}
            caption="Сравнение состояний конструкции, а не оценка компании. Публичный scoring, радар и тест зрелости в системе запрещены."
            rows={[
              { label: "Скорость решения", cells: [{ text: "Скорость одного человека", tone: "stop" }, { text: "Скорость мандата", tone: "go", strong: true }] },
              { label: "Владелец данных", cells: [{ text: "Не определён", tone: "stop" }, { text: "Закреплён в роли", tone: "go" }] },
              { label: "Ритм", cells: ["Совещание как способ решить", "Повестка решений"] },
              { label: "Отклонение", cells: [{ text: "Обнаруживается поздно", tone: "stop" }, { text: "Имеет владельца и срок", tone: "go" }] }
            ]}
          />
        </div>
      </Band>

      <Band tone="paper" id="how" eyebrow="Как работает · продуктовая лестница" title="Диагностика → Сессия → Спринт 30-60-90 → Сопровождение" aside="Маршрут един для 7 технологий" width="wide">
        <ProductLadder steps={d.ladder} activeIndex={ladder} onSelect={setLadder} />
      </Band>

      <Band tone="paperGrid" id="viz" eyebrow="Визуализации технологии" title="Схема объясняет быстрее текста" aside={`${viz + 1} / ${d.viz.length}`} width="wide">
        <VisualizationShowcase items={d.viz} activeIndex={viz} onSelect={setViz} showTabs />
      </Band>

      <Band tone="paper" id="cases" eyebrow="Кейсы · доказательство применимости" title="Что стало управляемым" width="wide">
        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(380px,1fr))", gap: "var(--space-6)" }}>
          {d.cases.map((c) => <CaseCard key={c.sector} {...c} href="#" />)}
        </div>
      </Band>

      <Band tone="dossierGrid" eyebrow="Кейс · управленческий поток" title="Один кейс как последовательность состояний" width="wide" tight>
        <CaseFlow steps={d.caseFlow} />
      </Band>

      <Band tone="paper" id="materials" eyebrow="Материалы и артефакты" title="One-page, презентация, пакет схем" width="wide">
        <div style={{ display: "grid", gap: "var(--space-3)", marginBottom: "var(--space-12)" }}>
          {d.materials.map((m) => <MaterialCard key={m.title} {...m} href="#" />)}
        </div>
        <OnePageBlock
          title="One-page технологии"
          description="Одна страница о том, что настраивает CLM, для кого и с чего начинается вход."
          bullets={["Ядро и шесть слоёв первого круга", "Четыре продукта технологии", "Условия входа в Диагностику"]}
          secondary={{ label: "Посмотреть кейсы", href: "#cases" }}
        />
      </Band>

      <CTABlock
        title="Диагностика первого круга"
        body="Первичный диагноз конструкции, управленческий вердикт и право на STOP."
        secondaryCta={{ label: "Получить one-page", href: "#materials" }}
        terms={d.ctaTerms}
      />

      <Band tone="paper" id="diagnostics" eyebrow="Заявка" title="Короткая заявка на Диагностику" width="wide">
        <div style={{ display: "grid", gridTemplateColumns: "minmax(320px,620px) 1fr", gap: "var(--space-16)", alignItems: "start" }}>
          <RequestDiagnosticsForm note="Ответ в течение двух рабочих дней. Диагностика не проводится на сайте." state={state} errors={errors} onSubmit={submit} />
          <div style={{ display: "grid", gap: "var(--space-5)", paddingLeft: "var(--space-5)", borderLeft: "2px solid var(--accent-tech)" }}>
            {d.ctaTerms.map((t, i) => (
              <div key={i} style={{ display: "grid", gridTemplateColumns: "26px 1fr", gap: "var(--space-3)" }}>
                <span style={{ fontFamily: "var(--font-mono)", fontSize: "var(--text-micro)", color: "var(--accent-tech)" }}>{String(i + 1).padStart(2, "0")}</span>
                <p style={{ fontSize: "var(--text-small)", color: "var(--text-muted)" }}>{t}</p>
              </div>
            ))}
            <Button variant="quiet" href="#top" trailing="↑">Вернуться к ядру технологии</Button>
          </div>
        </div>
      </Band>

      <Footer
        technology={d.technology}
        columns={d.footerColumns}
        technologies={d.technologies}
        note="Первый платный вход в любую технологию — Диагностика. Обещания результата до неё нет."
      />
    </div>
  );
}

Object.assign(window, { TechnologySiteCLM });
