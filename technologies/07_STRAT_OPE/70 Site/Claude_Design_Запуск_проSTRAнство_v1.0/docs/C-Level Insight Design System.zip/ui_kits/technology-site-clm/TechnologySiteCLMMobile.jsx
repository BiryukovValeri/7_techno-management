/* CLM technology site — mobile screen (390px). Same components, mobile behaviour rules applied. */
const { Header, StickySectionNav, ProductLadder, MobileVisualizationPreview, WhatItIsNot, CaseCard,
  RequestDiagnosticsForm, CTABlock, Band, Button, Tag } = window.CLevelInsightDesignSystem_27a32f;

function TechnologySiteCLMMobile() {
  const d = window.CLM;
  const [active, setActive] = React.useState("viz");
  const [open, setOpen] = React.useState(false);
  const [step, setStep] = React.useState(0);

  return (
    <div style={{ width: 390, margin: "0 auto", background: "var(--surface-page)", overflow: "hidden", border: "1px solid var(--line-hairline)" }}>
      <div style={{ padding: "14px 16px", borderBottom: "1px solid var(--line-hairline)", display: "grid", gap: 4 }}>
        <span style={{ fontFamily: "var(--font-display)", fontSize: 17, fontWeight: 700, color: "var(--text-display)" }}>{d.technology}</span>
        <span style={{ fontFamily: "var(--font-mono)", fontSize: 10, letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase", color: "var(--accent-tech)" }}>C-LEVEL INSIGHT · ТЕХНОЛОГИЯ {d.index}</span>
      </div>

      {/* Mobile hero: schema becomes a fixed 16:9 preview, text below it — never a cropped cover */}
      <div style={{ padding: "20px 16px", background: "var(--surface-page)", backgroundImage: "var(--grid-paper)", backgroundSize: "var(--grid-repeat)" }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase", color: "var(--text-muted)", paddingBottom: 8, borderBottom: "2px solid var(--accent-tech)", display: "inline-block" }}>Ядро технологии</div>
        <h1 style={{ fontSize: "var(--text-hero)", lineHeight: 1.06, margin: "16px 0 0" }}>{d.hero.title}</h1>
        <p style={{ marginTop: 12, fontSize: 17, lineHeight: 1.55, color: "var(--cli-slate-600)" }}>{d.hero.formula}</p>
        <div style={{ display: "grid", gap: 8, marginTop: 20 }}>
          <Button variant="primary" size="lg" href="#diagnostics">Запросить Диагностику</Button>
          <Button variant="ghost" size="lg" href="#how" trailing="→">Посмотреть, как работает</Button>
        </div>
      </div>

      <StickySectionNav items={d.sections.slice(0, 6)} activeId={active} onSelect={setActive} orientation="horizontal" />

      <div style={{ padding: "24px 16px", display: "grid", gap: 32 }}>
        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>Визуализация · mobile preview</div>
          <MobileVisualizationPreview
            item={{ src: d.viz[0].src, alt: d.viz[0].alt, title: d.viz[0].title, caption: "Полная схема открывается на весь экран с прокруткой." }}
            open={open} onOpen={() => setOpen(true)} onClose={() => setOpen(false)} />
        </div>

        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>Как работает · вертикальная лестница</div>
          <ProductLadder steps={d.ladder} orientation="vertical" activeIndex={step} onSelect={setStep} />
        </div>

        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>Это не · стек вместо таблицы</div>
          <div style={{ display: "grid", gap: 10 }}>
            {d.isNot.slice(0, 3).map((n, i) => (
              <div key={n.title} style={{ border: "1px solid var(--cli-paper-500)", background: "var(--surface-card)", padding: 14, display: "grid", gap: 8 }}>
                <Tag role="stop" style={{ justifySelf: "start" }}>{n.title}</Tag>
                <p style={{ fontSize: 15, color: "var(--cli-red-700)" }}>{n.text}</p>
                <div style={{ borderTop: "1px solid var(--cli-paper-400)", paddingTop: 8, display: "grid", gap: 6 }}>
                  <Tag role="data" style={{ justifySelf: "start" }}>{d.isThis[i].title}</Tag>
                  <p style={{ fontSize: 15 }}>{d.isThis[i].text}</p>
                </div>
              </div>
            ))}
          </div>
        </div>

        <div>
          <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-label)", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>Кейс</div>
          <CaseCard {...d.cases[0]} />
        </div>
      </div>

      <div id="diagnostics" style={{ padding: "24px 16px", background: "var(--surface-dossier-deep)", backgroundImage: "var(--grid-dossier)", backgroundSize: "var(--grid-repeat)", display: "grid", gap: 16 }}>
        <div style={{ fontFamily: "var(--font-mono)", fontSize: 11, letterSpacing: "var(--tracking-eyebrow)", textTransform: "uppercase", color: "var(--accent-tech)" }}>Первый платный вход</div>
        <h2 style={{ color: "var(--cli-paper-200)", fontSize: 30, lineHeight: 1.1 }}>Диагностика первого круга</h2>
        <p style={{ fontSize: 17, color: "var(--text-on-dossier-muted)" }}>Первичный диагноз конструкции, управленческий вердикт и право на STOP.</p>
        <Button variant="onDark" size="lg">Запросить Диагностику</Button>
      </div>

      <div style={{ padding: "24px 16px" }}>
        <RequestDiagnosticsForm title="Заявка" note="Ответ в течение двух рабочих дней." />
      </div>
    </div>
  );
}

Object.assign(window, { TechnologySiteCLMMobile });
